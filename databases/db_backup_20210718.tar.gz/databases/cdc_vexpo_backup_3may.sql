-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: cdc_vexpo_backup_3may
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cdc_vexpo_backup_3may`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cdc_vexpo_backup_3may` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cdc_vexpo_backup_3may`;

--
-- Table structure for table `cdc_account`
--

DROP TABLE IF EXISTS `cdc_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdc_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_card` varchar(128) DEFAULT NULL,
  `id_card_type` varchar(128) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `username` varchar(128) DEFAULT NULL,
  `nama` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `tempat_lahir` varchar(256) DEFAULT NULL,
  `account_type` enum('admin','peserta','perusahaan','konsultan','psikologis') NOT NULL DEFAULT 'peserta',
  `namafile` text,
  `pendidikan` enum('d3','s1','s2','s3') DEFAULT NULL,
  `universitas` varchar(256) DEFAULT NULL,
  `fakultas` varchar(256) DEFAULT NULL,
  `jurusan` varchar(128) DEFAULT NULL,
  `tahun_lulus` int(5) DEFAULT NULL,
  `comp_bidang_usaha` text,
  `comp_deskripsi` text,
  `comp_website` varchar(256) DEFAULT NULL,
  `comp_contact_person` bigint(20) DEFAULT NULL,
  `comp_alamat` text NOT NULL,
  `date_created` date DEFAULT NULL,
  `date_updated` date DEFAULT NULL,
  `time_created` time DEFAULT NULL,
  `time_updated` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdc_account`
--

LOCK TABLES `cdc_account` WRITE;
/*!40000 ALTER TABLE `cdc_account` DISABLE KEYS */;
INSERT INTO `cdc_account` VALUES (16,NULL,NULL,'zalbinaridwan@gmail.com',NULL,'M. Ridwan Zalbina','25d55ad283aa400af464c76d713c07ad',81919992002,NULL,NULL,'peserta','logo-sistem-rpn.png','s1','Universitas Sriwijaya','Ilmu Komputer','Sistem Komputer',2016,NULL,NULL,NULL,NULL,'','2021-02-03','2021-02-07','07:44:27','07:44:27'),(17,NULL,NULL,'mridwanzalbina@gmail.com',NULL,'M Ridwan Zalbina','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,'s1','Universitas Sriwijaya','Ilmu Komputer','Sistem Komputer',2016,NULL,NULL,NULL,NULL,'','2021-02-03','2021-02-03',NULL,NULL),(18,NULL,NULL,'santi@gmail.com',NULL,'Santi M','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,'s1','Universitas Sriwijaya','Ilmu Komputer','Sistem Komputer',2018,NULL,NULL,NULL,NULL,'','2021-02-03','2021-02-03','07:14:32',NULL),(19,NULL,NULL,'admin@cdcunsri.ac.id',NULL,'Admin CDC UNSRI','25d55ad283aa400af464c76d713c07ad',811100100100,NULL,NULL,'admin','MRZCOURSE.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2021-02-04',NULL,NULL,NULL),(23,NULL,NULL,'nurulafifah@gmail.com',NULL,'Nurul Afifah','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL),(24,NULL,NULL,'triwandas@gmail.com',NULL,'Tri Wanda Septian','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL),(26,NULL,NULL,'perekuda@gmail.com',NULL,'PT PEREKUDA','25d55ad283aa400af464c76d713c07ad',82175112151,NULL,NULL,'perusahaan','download.jpeg',NULL,NULL,NULL,NULL,NULL,'Pertanian','Perusahaan Pupuk Indonesia, saat ini membuka lowongan pekerjaan sebanyak 100 posisi baru','www.pusri.co.id',0,' Jl. Mayor Zen Palembang 30118','2021-02-05','2021-02-06','06:09:00','06:09:00'),(27,NULL,NULL,'abdiilkom@gmail.com',NULL,'Abdi Ilkom','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,'Universitas Sriwijaya','Ilmu Komputer','Sistem Komputer',2021,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL),(28,NULL,NULL,'taufikilkom@gmail.com',NULL,'Taufik Ilkom','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,'Universitas Sriwijaya','Ilmu Komputer','Sistem Komputer',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL),(29,NULL,NULL,'ptpusri@gmail.com',NULL,'PT Pusri, Tbk','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'perusahaan','download.jpeg',NULL,NULL,NULL,NULL,NULL,'Pupuk','Perusahaan Pupuk Nasional, PT PUSRI telah lama berkiprah di Indonesia sebagai',NULL,NULL,'',NULL,NULL,NULL,NULL),(30,NULL,NULL,'semenbaturaja@gmail.com',NULL,'PT Semen Baturaja','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'perusahaan','Logo_Semen_Baturaja.jpg',NULL,NULL,NULL,NULL,NULL,'Semen','PT Semen Baturaja, merupakan perusahaan BUMN yang bergerak di bidang mineral dan pengolahamn semen ',NULL,NULL,'',NULL,NULL,NULL,NULL),(31,NULL,NULL,'ptsemenpadang@gmail.com',NULL,'PT Semen Padang, Tbk','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'perusahaan',NULL,NULL,NULL,NULL,NULL,NULL,'Pupuk','Perusahaan Pupuk Nasional, PT PUSRI telah lama berkiprah di Indonesia sebagai',NULL,NULL,'',NULL,NULL,NULL,NULL),(32,NULL,NULL,'ptbta@gmail.com',NULL,'PT Bukit Asam Persero','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'perusahaan',NULL,NULL,NULL,NULL,NULL,NULL,'Batubara',NULL,NULL,NULL,'','2021-04-06','2021-04-06','10:32:00','10:32:00'),(33,NULL,NULL,'ptsemenbaturaja@gmail.com',NULL,'PT Semen Baturaja','25d55ad283aa400af464c76d713c07ad',71110020010,NULL,NULL,'perusahaan','Logo_Semen_Baturaja.jpg',NULL,NULL,NULL,NULL,NULL,'Semen','PT Semen Baturaja','cdcvexpo.ridwanzal.com',0,'Jl Abikusno Cokrosuyoso','2021-04-06','2021-04-06','11:08:09','11:08:09');
/*!40000 ALTER TABLE `cdc_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cdc_account_activity`
--

DROP TABLE IF EXISTS `cdc_account_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdc_account_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `ip_address_visitor` varchar(64) NOT NULL,
  `date_created` date NOT NULL,
  `time_created` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdc_account_activity`
--

LOCK TABLES `cdc_account_activity` WRITE;
/*!40000 ALTER TABLE `cdc_account_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `cdc_account_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cdc_consulting`
--

DROP TABLE IF EXISTS `cdc_consulting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdc_consulting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` date NOT NULL,
  `date_updated` date NOT NULL,
  `time_created` time NOT NULL,
  `time_updated` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdc_consulting`
--

LOCK TABLES `cdc_consulting` WRITE;
/*!40000 ALTER TABLE `cdc_consulting` DISABLE KEYS */;
/*!40000 ALTER TABLE `cdc_consulting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cdc_dropcv`
--

DROP TABLE IF EXISTS `cdc_dropcv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdc_dropcv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `namafile` text NOT NULL,
  `basepath` text NOT NULL,
  `date_created` date DEFAULT NULL,
  `date_updated` date NOT NULL,
  `time_created` time DEFAULT NULL,
  `time_updated` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dropcv_to_account` (`account_id`),
  CONSTRAINT `dropcv_to_account` FOREIGN KEY (`account_id`) REFERENCES `cdc_account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdc_dropcv`
--

LOCK TABLES `cdc_dropcv` WRITE;
/*!40000 ALTER TABLE `cdc_dropcv` DISABLE KEYS */;
INSERT INTO `cdc_dropcv` VALUES (5,16,'expo1.pdf','',NULL,'0000-00-00',NULL,NULL);
/*!40000 ALTER TABLE `cdc_dropcv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cdc_log_activity`
--

DROP TABLE IF EXISTS `cdc_log_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdc_log_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `peserta_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdc_log_activity`
--

LOCK TABLES `cdc_log_activity` WRITE;
/*!40000 ALTER TABLE `cdc_log_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `cdc_log_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cdc_schedule`
--

DROP TABLE IF EXISTS `cdc_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdc_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `tanggal_pelaksanaan` date NOT NULL,
  `waktu_pelaksanaan` time NOT NULL,
  `date_created` date NOT NULL,
  `time_created` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sch_to_account` (`account_id`),
  CONSTRAINT `sch_to_account` FOREIGN KEY (`account_id`) REFERENCES `cdc_account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cdc_schedule`
--

LOCK TABLES `cdc_schedule` WRITE;
/*!40000 ALTER TABLE `cdc_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `cdc_schedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:19
