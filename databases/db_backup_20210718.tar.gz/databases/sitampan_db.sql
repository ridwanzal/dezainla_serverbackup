-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: sitampan_db
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sitampan_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sitampan_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sitampan_db`;

--
-- Table structure for table `sit_backup`
--

DROP TABLE IF EXISTS `sit_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1 to 5 full/alert/firewall/rule/log',
  `description` text NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_backup`
--

LOCK TABLES `sit_backup` WRITE;
/*!40000 ALTER TABLE `sit_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `sit_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_mode`
--

DROP TABLE IF EXISTS `sit_mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_mode` (
  `id` int(11) NOT NULL,
  `mode` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_mode`
--

LOCK TABLES `sit_mode` WRITE;
/*!40000 ALTER TABLE `sit_mode` DISABLE KEYS */;
/*!40000 ALTER TABLE `sit_mode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_net_interface`
--

DROP TABLE IF EXISTS `sit_net_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_net_interface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `device` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_net_interface`
--

LOCK TABLES `sit_net_interface` WRITE;
/*!40000 ALTER TABLE `sit_net_interface` DISABLE KEYS */;
/*!40000 ALTER TABLE `sit_net_interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_net_network`
--

DROP TABLE IF EXISTS `sit_net_network`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_net_network` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(64) NOT NULL,
  `netmask` varchar(64) NOT NULL,
  `id_interface` int(11) NOT NULL,
  `is_running` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_net_network`
--

LOCK TABLES `sit_net_network` WRITE;
/*!40000 ALTER TABLE `sit_net_network` DISABLE KEYS */;
/*!40000 ALTER TABLE `sit_net_network` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_sec_alert`
--

DROP TABLE IF EXISTS `sit_sec_alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_sec_alert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` varchar(256) NOT NULL,
  `priority` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `protocol` varchar(64) NOT NULL,
  `class` int(11) NOT NULL,
  `source_ip` varchar(64) NOT NULL,
  `source_port` varchar(64) NOT NULL,
  `destination_ip` varchar(64) NOT NULL,
  `destination_port` varchar(64) NOT NULL,
  `sid` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `firewall` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_sec_alert`
--

LOCK TABLES `sit_sec_alert` WRITE;
/*!40000 ALTER TABLE `sit_sec_alert` DISABLE KEYS */;
INSERT INTO `sit_sec_alert` VALUES (1,'04-06-2021 09:52:49',1,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap',0,0),(2,'04-06-2021 10:04:15',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap',0,0),(3,'04-06-2021 10:10:34',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap',0,0),(4,'04-06-2021 10:29:46',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap',0,0),(5,'13-07-2021 11:05:09',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap',0,0),(6,'13-07-2021 11:15:24',0,1,'icmp',0,'192.168.120.21','19211','192.168.120.21','193','19212121321s','asap',0,0);
/*!40000 ALTER TABLE `sit_sec_alert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_sec_firewall`
--

DROP TABLE IF EXISTS `sit_sec_firewall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_sec_firewall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` varchar(256) NOT NULL,
  `priority` int(11) NOT NULL COMMENT '(0-not prior)\r\n(1-low)\r\n(2-medium)\r\n(3-high)',
  `type` tinyint(1) NOT NULL COMMENT '(0-deny)\r\n(1-allow)',
  `protocol` varchar(64) NOT NULL,
  `class` int(11) NOT NULL,
  `source_ip` varchar(64) NOT NULL,
  `source_port` varchar(64) NOT NULL,
  `destination_ip` varchar(64) NOT NULL,
  `destination_port` varchar(64) NOT NULL,
  `sid` varchar(64) NOT NULL,
  `duration` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '(0-nonactive)\r\n(1-active)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_sec_firewall`
--

LOCK TABLES `sit_sec_firewall` WRITE;
/*!40000 ALTER TABLE `sit_sec_firewall` DISABLE KEYS */;
INSERT INTO `sit_sec_firewall` VALUES (12,'01-06-2021 15:46:24',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s',2000,'asap',1),(13,'01-06-2021 16:05:58',0,1,'tcp',0,'192.168.120.22','192','192.168.120.21','193','19212121321s',2000,'asap',1),(14,'01-06-2021 16:06:02',0,1,'tcp',0,'192.168.120.21','19221','192.168.120.21','193','19212121321s',2000,'asap',1),(16,'13-07-2021 11:05:04',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s',2000,'asap',1),(17,'13-07-2021 11:15:04',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321sssssssss',2000,'asap',1);
/*!40000 ALTER TABLE `sit_sec_firewall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_sec_host`
--

DROP TABLE IF EXISTS `sit_sec_host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_sec_host` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL COMMENT '(0-not prior)\r\n(1-low)\r\n(2-medium)\r\n(3-high)',
  `datetime` datetime NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '(0-deny)\r\n(1-allow)',
  `ip_address` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `firewall` tinyint(1) NOT NULL COMMENT '(0-nonactive)\r\n(1-active)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_sec_host`
--

LOCK TABLES `sit_sec_host` WRITE;
/*!40000 ALTER TABLE `sit_sec_host` DISABLE KEYS */;
INSERT INTO `sit_sec_host` VALUES (1,0,'0000-00-00 00:00:00',1,'192.168.120.21','asap',1),(2,1,'0000-00-00 00:00:00',1,'192.168.120.22','asap',1),(3,2,'0000-00-00 00:00:00',1,'192.168.120.21','asap',1),(4,1,'0000-00-00 00:00:00',1,'192.168.120.21','asap',1),(5,0,'0000-00-00 00:00:00',1,'192.168.120.21','asapddd',1);
/*!40000 ALTER TABLE `sit_sec_host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_sec_rules`
--

DROP TABLE IF EXISTS `sit_sec_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_sec_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL,
  `priority` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `protocol` varchar(64) NOT NULL,
  `class` int(11) NOT NULL,
  `source_ip` varchar(64) NOT NULL,
  `source_port` varchar(64) NOT NULL,
  `destination_ip` varchar(64) NOT NULL,
  `destination_port` varchar(64) NOT NULL,
  `sid` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `payload` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `firewall` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_sec_rules`
--

LOCK TABLES `sit_sec_rules` WRITE;
/*!40000 ALTER TABLE `sit_sec_rules` DISABLE KEYS */;
INSERT INTO `sit_sec_rules` VALUES (1,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap','asap',0,0),(4,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap','asap',0,0),(5,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap1111111','asap',0,0),(6,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asapssssssssss','asap',0,0),(7,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321sddddddddddddd','asap','asap',0,0),(8,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321sssxxx','asap','asap',0,0),(10,'0000-00-00 00:00:00',0,1,'tcp',0,'192.168.120.21','192','192.168.120.21','193','19212121321s','asap','asap',0,1);
/*!40000 ALTER TABLE `sit_sec_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_terminal`
--

DROP TABLE IF EXISTS `sit_terminal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_terminal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `command` text NOT NULL,
  `session` text NOT NULL,
  `id_user` int(11) NOT NULL,
  `output` text NOT NULL,
  `exec` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_terminal`
--

LOCK TABLES `sit_terminal` WRITE;
/*!40000 ALTER TABLE `sit_terminal` DISABLE KEYS */;
INSERT INTO `sit_terminal` VALUES (1,'cd 1.php 2.php','1',1,'cd 1.php 2.php','cd 1.php 2.php',0),(2,'cd /','1',1,'cd /','cd /',0);
/*!40000 ALTER TABLE `sit_terminal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sit_user`
--

DROP TABLE IF EXISTS `sit_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(256) NOT NULL,
  `fullname` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `remotes` varchar(256) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leveling` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sit_user`
--

LOCK TABLES `sit_user` WRITE;
/*!40000 ALTER TABLE `sit_user` DISABLE KEYS */;
INSERT INTO `sit_user` VALUES (1,'admin','Admin SI-TAMPAN 22','7c222fb2927d828af22f592134e8932480637c0d','1','2021-05-25 04:51:24',1,0,''),(9,'ridwanzal','M. Ridwan Zalbina','7c222fb2927d828af22f592134e8932480637c0d','1','2021-05-25 02:13:45',1,0,''),(11,'zipruz','Ahmad Heryanto','7c222fb2927d828af22f592134e8932480637c0d','1','2021-05-25 04:40:11',1,1,''),(12,'triwandaseptian','Tri Wanda Septian','7c222fb2927d828af22f592134e8932480637c0d','1','2021-05-25 04:40:28',1,1,'');
/*!40000 ALTER TABLE `sit_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:23
