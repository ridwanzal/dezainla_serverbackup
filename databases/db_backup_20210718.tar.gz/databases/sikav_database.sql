-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: sikav_database
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sikav_database`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sikav_database` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sikav_database`;

--
-- Table structure for table `sikav_cost`
--

DROP TABLE IF EXISTS `sikav_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_cost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_sinta` int(11) NOT NULL,
  `id_google` int(11) NOT NULL,
  `id_afiliasi` int(11) NOT NULL,
  `nama_inventor` varchar(128) NOT NULL,
  `email_inventor` varchar(128) NOT NULL,
  `institusi` varchar(128) NOT NULL,
  `unit_kerja` varchar(128) NOT NULL,
  `judul_penelitian` varchar(256) NOT NULL,
  `total_biaya` double NOT NULL,
  `asal_biaya` varchar(256) NOT NULL,
  `lampiran` text NOT NULL,
  `qi` double NOT NULL,
  `ti` double NOT NULL,
  `ki` double NOT NULL,
  `pi` double NOT NULL,
  `atbp` double NOT NULL,
  `tanggal` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_cost`
--

LOCK TABLES `sikav_cost` WRITE;
/*!40000 ALTER TABLE `sikav_cost` DISABLE KEYS */;
INSERT INTO `sikav_cost` VALUES (93,112910,0,1066,'HARIS WAHYUDI','haris.wahyudi@mercubuana.ac.id','Universitas Mercu Buana','Teknik Mesin','PENGEMBANGAN PADUAN LOGAM NANO Fe-Mn UNTUK APLIKASI BIODEGRADABLE STENT',50000000,'Hibah Ristek','kosong',475,48,4588910.1338432,3900000,8488910.1338432,'2020-11-16 14:13:33'),(94,112910,0,1066,'HARIS WAHYUDI','haris.wahyudi@mercubuana.ac.id','Universitas Mercu Buana','Teknik Mesin','PENGEMBANGAN PADUAN LOGAM NANO Fe-Mn UNTUK APLIKASI BIODEGRADABLE STENT',50000000,'Dikti Kemendikbud','kosong',320,48,6521739.1304348,3750000,10271739.130435,'2020-11-20 04:46:43'),(95,112910,0,1066,'HARIS WAHYUDI','haris.wahyudi@mercubuana.ac.id','Universitas Mercu Buana','Teknik Mesin','PENGEMBANGAN PADUAN LOGAM NANO Fe-Mn UNTUK APLIKASI BIODEGRADABLE STENT',50000000,'Hibah Ristek','kosong',450,48,4819277.1084337,3750000,8569277.1084337,'2020-12-28 23:45:21'),(96,112910,0,1066,'HARIS WAHYUDI','haris.wahyudi@mercubuana.ac.id','Universitas Mercu Buana','Teknik Mesin','PENGEMBANGAN PADUAN LOGAM NANO Fe-Mn UNTUK APLIKASI BIODEGRADABLE STENT',50000000,'Hibah Ristek','kosong',320,48,6521739.1304348,4981312,11503051.130435,'2021-01-16 08:06:17'),(97,112910,0,1066,'HARIS WAHYUDI','haris.wahyudi@mercubuana.ac.id','Universitas Mercu Buana','Teknik Mesin','PENGEMBANGAN PADUAN LOGAM NANO Fe-Mn UNTUK APLIKASI BIODEGRADABLE STENT',50000000,'Dikti Kemendikbud','kosong',450,48,4819277.1084337,3750000,8569277.1084337,'2021-01-18 10:13:54'),(98,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test',1234567,'Hibah Ristek','kosong',400,33,94089.401847575,1934567,2028656.4018476,'2021-04-18 04:07:10'),(99,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test',1234567,'Hibah Ristek','kosong',400,33,94089.401847575,1934567,2028656.4018476,'2021-04-18 04:08:46'),(100,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test test',1234567,'Hibah Ristek','kosong',400,9,27166.511002445,1934567,1961733.5110024,'2021-04-18 04:11:59'),(101,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test123',123,'Lainnya','kosong',400,9,2.7066014669927,823456,823458.70660147,'2021-04-20 09:44:25'),(102,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test1234\"><img src=x onerror=alert(\'XSS\');>',123,'Lainnya','kosong',400,9,2.7066014669927,1934567,1934569.7066015,'2021-04-20 09:56:45'),(103,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test-abc',1234,'Lainnya','kosong',400,9,27.154034229829,823456,823483.15403423,'2021-04-20 10:03:08'),(104,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test-1234',123,'Lainnya','kosong',400,9,2.7066014669927,823456,823458.70660147,'2021-04-20 10:12:03'),(105,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum\"><img src=x onerror=alert(\'XSS\');>','test-12345',1234,'Lainnya','kosong',400,9,27.154034229829,712345,712372.15403423,'2021-04-20 10:15:13'),(106,1,0,3,'ANIS MASHDUROHATUN\"><img src=x onerror=alert(\'XSS\');>','anism@unissula.ac.id','Universitas Islam Sultan Agung','Ilmu Hukum','test-1234567',1234,'Lainnya','kosong',400,9,27.154034229829,1934567,1934594.1540342,'2021-04-20 10:17:05'),(107,1,0,3,'ANIS MASHDUROHATUN','anism@unissula.ac.id','Universitas Islam Sultan Agung\"><img src=x onerror=alert(\'XSS\');>','Ilmu Hukum','test-12345678',12345,'Lainnya','kosong',400,9,271.65036674817,823456,823727.65036675,'2021-04-20 10:18:28');
/*!40000 ALTER TABLE `sikav_cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_cost_nonpaten`
--

DROP TABLE IF EXISTS `sikav_cost_nonpaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_cost_nonpaten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cost` int(11) NOT NULL,
  `id_sinta` int(11) NOT NULL,
  `pub_internasional` int(11) NOT NULL,
  `pub_nasional` int(11) NOT NULL,
  `buku_internasional` int(11) NOT NULL,
  `buku_nasional` int(11) NOT NULL,
  `pub_prod_internasional` int(11) NOT NULL,
  `pub_prod_nasional` int(11) NOT NULL,
  `ki` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cost_nonpaten` (`id_cost`),
  CONSTRAINT `cost_nonpaten` FOREIGN KEY (`id_cost`) REFERENCES `sikav_cost` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_cost_nonpaten`
--

LOCK TABLES `sikav_cost_nonpaten` WRITE;
/*!40000 ALTER TABLE `sikav_cost_nonpaten` DISABLE KEYS */;
INSERT INTO `sikav_cost_nonpaten` VALUES (92,93,112910,8,1,1,1,2,1,0),(93,94,112910,8,0,0,0,0,0,0),(94,95,112910,8,1,1,1,1,1,0),(95,96,112910,8,0,0,0,0,0,0),(96,97,112910,8,1,1,1,1,1,0),(97,98,1,10,0,0,0,0,0,0),(98,99,1,10,0,0,0,0,0,0),(99,100,1,10,0,0,0,0,0,0),(100,101,1,10,0,0,0,0,0,0),(101,102,1,10,0,0,0,0,0,0),(102,103,1,10,0,0,0,0,0,0),(103,104,1,10,0,0,0,0,0,0),(104,105,1,10,0,0,0,0,0,0),(105,106,1,10,0,0,0,0,0,0),(106,107,1,10,0,0,0,0,0,0);
/*!40000 ALTER TABLE `sikav_cost_nonpaten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_cost_paten`
--

DROP TABLE IF EXISTS `sikav_cost_paten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_cost_paten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cost` int(11) NOT NULL,
  `id_sinta` int(11) NOT NULL,
  `judul_invensi` text NOT NULL,
  `jenis_paten` varchar(32) NOT NULL,
  `status_permohonan` varchar(32) NOT NULL,
  `no_pendaftaran` varchar(128) NOT NULL,
  `sertifikat` varchar(128) NOT NULL,
  `asal_biaya_pendaftaran` varchar(128) NOT NULL,
  `lampiran` text NOT NULL,
  `biaya_proses_lain` double NOT NULL,
  `bobot` int(11) NOT NULL,
  `biaya_pendaftaran` double NOT NULL,
  `biaya_percepatan` double NOT NULL,
  `biaya_substantif` double NOT NULL,
  `total_bobot` int(11) NOT NULL,
  `pi` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cost_paten` (`id_cost`),
  CONSTRAINT `cost_paten` FOREIGN KEY (`id_cost`) REFERENCES `sikav_cost` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_cost_paten`
--

LOCK TABLES `sikav_cost_paten` WRITE;
/*!40000 ALTER TABLE `sikav_cost_paten` DISABLE KEYS */;
INSERT INTO `sikav_cost_paten` VALUES (102,93,112910,'MESIN KOMPUTER KONTROL NUMERIK ROUTER TIGA SUMBU PORTABEL','paten_granted','tersertifikasi','P00201707747','IDP000057134','','paten_granted',150000,48,350000,400000,3000000,48,0),(103,94,112910,'MESIN KOMPUTER KONTROL NUMERIK ROUTER TIGA SUMBU PORTABEL','paten_granted','tersertifikasi','P00201707747','IDP000057134','','paten_granted',0,48,350000,400000,3000000,48,0),(104,95,112910,'MESIN KOMPUTER KONTROL NUMERIK ROUTER TIGA SUMBU PORTABEL','paten_granted','tersertifikasi','P00201707747','IDP000057134','Raih KI','paten_granted',0,48,350000,400000,3000000,48,0),(105,96,112910,'PANEL PRAKTIKUM 2 (DUA)SISI PNEUMATIK/HIDROLIK','paten_granted','tersertifikasi','S00201701826','IDS000001842','','paten_granted',1231312,48,350000,400000,3000000,48,0),(106,97,112910,'MESIN KOMPUTER KONTROL NUMERIK ROUTER TIGA SUMBU PORTABEL','paten_granted','tersertifikasi','P00201707747','IDP000057134','','paten_granted',0,48,350000,400000,3000000,48,0),(107,98,1,'test test test','paten_sederhana','tersertifikasi','1234567890','1234567890','Institusi Penghasil/Pemilik Invensi','paten_sederhana',1234567,33,200000,0,500000,33,0),(108,99,1,'test test test','paten_sederhana','tersertifikasi','1234567890','1234567890','Institusi Penghasil/Pemilik Invensi','paten_sederhana',1234567,33,200000,0,500000,33,0),(109,100,1,'test test \"><script>alert(\'test\')</script>','paten_sederhana','terdaftar','123456789','123456787','Raih KI','paten_sederhana',1234567,9,200000,0,500000,9,0),(110,101,1,'testtest\"><script>alert(\'xss\')</script> ','paten_sederhana','terdaftar','123456','123456','Lainnya','paten_sederhana',123456,9,200000,0,500000,9,0),(111,102,1,'test1234','paten_sederhana','terdaftar','1234567','1234567','Lainnya','paten_sederhana',1234567,9,200000,0,500000,9,0),(112,103,1,'test-abc','paten_sederhana','terdaftar','1234test\"><img src=x onerror=alert(\'XSS\');>','123456','Lainnya','paten_sederhana',123456,9,200000,0,500000,9,0),(113,104,1,'test-1234','paten_sederhana','terdaftar','123456','123456\"><img src=x onerror=alert(document.domain);>','Lainnya','paten_sederhana',123456,9,200000,0,500000,9,0),(114,105,1,'test-123456','paten_sederhana','terdaftar','123456','123456','Lainnya','paten_sederhana',12345,9,200000,0,500000,9,0),(115,106,1,'testtesttest','paten_sederhana','terdaftar','1234567','1234567','','paten_sederhana',1234567,9,200000,0,500000,9,0),(116,107,1,'test-12345678','paten_sederhana','terdaftar','1234567','1234567','Lainnya','paten_sederhana',123456,9,200000,0,500000,9,0);
/*!40000 ALTER TABLE `sikav_cost_paten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_cost_paten_inflasi`
--

DROP TABLE IF EXISTS `sikav_cost_paten_inflasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_cost_paten_inflasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cost` int(11) NOT NULL,
  `id_sinta` int(11) NOT NULL,
  `no_pendaftaran` varchar(128) NOT NULL,
  `tahunke` int(2) NOT NULL,
  `tanggal_daftar` text NOT NULL,
  `tanggal_hitung` text NOT NULL,
  `nilai_inflasi` double NOT NULL,
  `nilai_atbp_paten` double NOT NULL,
  `nilai_atbp_paten_inflasi` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cost_paten_inflasi` (`id_cost`),
  CONSTRAINT `cost_paten_inflasi` FOREIGN KEY (`id_cost`) REFERENCES `sikav_cost` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_cost_paten_inflasi`
--

LOCK TABLES `sikav_cost_paten_inflasi` WRITE;
/*!40000 ALTER TABLE `sikav_cost_paten_inflasi` DISABLE KEYS */;
INSERT INTO `sikav_cost_paten_inflasi` VALUES (13,93,112910,'P00201707747',1,'2018-05-25','2020-11-16',0,8488910.1338432,8488910.1338432),(14,93,112910,'P00201707747',2,'2018-05-25','2020-11-16',2.5,8488910.1338432,8701132.8871893),(15,93,112910,'P00201707747',3,'2018-05-25','2020-11-16',2.4,8488910.1338432,8692643.9770555),(16,94,112910,'P00201707747',1,'2018-05-25','2020-11-20',0,10271739.130435,10271739.130435),(17,94,112910,'P00201707747',2,'2018-05-25','2020-11-20',2.4,10271739.130435,10518260.869565),(18,94,112910,'P00201707747',3,'2018-05-25','2020-11-20',2.3,10271739.130435,10507989.130435),(19,95,112910,'P00201707747',1,'2018-05-25','2020-12-29',0,8569277.1084337,8569277.1084337),(20,95,112910,'P00201707747',2,'2018-05-25','2020-12-29',0.2,8569277.1084337,8586415.6626506),(21,95,112910,'P00201707747',3,'2018-05-25','2020-12-29',0.4,8569277.1084337,8603554.2168675),(22,96,112910,'S00201701826',1,'2017-07-07','2021-01-16',0,11503051.130435,11503051.130435),(23,96,112910,'S00201701826',2,'2017-07-07','2021-01-16',0.2,11503051.130435,11526057.232696),(24,96,112910,'S00201701826',3,'2017-07-07','2021-01-16',0.5,11503051.130435,11560566.386087),(25,96,112910,'S00201701826',4,'2017-07-07','2021-01-16',2.1,11503051.130435,11744615.204174),(26,97,112910,'P00201707747',1,'2018-05-25','2021-01-18',0,8569277.1084337,8569277.1084337),(27,97,112910,'P00201707747',2,'2018-05-25','2021-01-18',1.2,8569277.1084337,8672108.4337349),(28,97,112910,'P00201707747',3,'2018-05-25','2021-01-18',1.4,8569277.1084337,8689246.9879518),(29,98,1,'1234567890',1,'2019-01-01','2020-01-01',0,2028656.4018476,2028656.4018476),(30,98,1,'1234567890',2,'2019-01-01','2020-01-01',0,2028656.4018476,2028656.4018476),(31,99,1,'1234567890',1,'2019-01-01','2020-01-01',0,2028656.4018476,2028656.4018476),(32,99,1,'1234567890',2,'2019-01-01','2020-01-01',0,2028656.4018476,2028656.4018476),(33,100,1,'123456789',1,'2020-09-01','2020-09-01',0,1961733.5110024,1961733.5110024),(34,101,1,'123456',1,'2020-01-01','2020-01-01',0,823458.70660147,823458.70660147),(35,102,1,'1234567',1,'2020-01-01','2020-01-01',0,1934569.7066015,1934569.7066015),(36,103,1,'1234test\"><img src=x onerror=alert(\'XSS\');>',1,'2020-01-01','2020-01-01',0,823483.15403423,823483.15403423),(37,104,1,'123456',1,'2020-01-01','2020-01-01',0,823458.70660147,823458.70660147),(38,105,1,'123456',1,'2020-01-01','2020-01-01',0,712372.15403423,712372.15403423),(39,106,1,'1234567',1,'2020-01-01','2020-01-01',0,1934594.1540342,1934594.1540342),(40,107,1,'1234567',1,'2020-01-01','2020-01-01',0,823727.65036675,823727.65036675);
/*!40000 ALTER TABLE `sikav_cost_paten_inflasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_hki`
--

DROP TABLE IF EXISTS `sikav_hki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_hki` (
  `hki_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sinta_id` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `inventor` varchar(255) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `jenis` varchar(100) DEFAULT NULL,
  `tahun` year(4) DEFAULT NULL,
  `no_daftar` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `no_hki` varchar(100) DEFAULT NULL,
  `url_hki` varchar(255) DEFAULT NULL,
  `berkas` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hki_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_hki`
--

LOCK TABLES `sikav_hki` WRITE;
/*!40000 ALTER TABLE `sikav_hki` DISABLE KEYS */;
INSERT INTO `sikav_hki` VALUES (1,1,NULL,'ANIS MASHDUROHATUN, M. MIFTAKUL AMIN, SLAMET WIDODO','APLIKASI MOBILE MUSICMOO SEBAGAI SARANA PENCARIAN JUDUL LAGU','Paten Sederhana',2017,'2017-01/X/012','terdaftar','2017-01','2017-099999',NULL),(2,1,NULL,'ANIS MASHDUROHATUN','METODE ISOLASI KOLAGEN DARI TULANG','Paten',2017,'2017-01/SBP-0999','granted','2017-01','2017-099999',NULL),(3,1,NULL,'ANIS MASHDUROHATUN','FORMULA SABUN CAIR PENYUCI NAJIS MUGHALLADZAH','Paten Sederhana',2017,'2017-099999','granted','2017-099999','2017-099999',NULL),(4,1,NULL,'ANIS MASHDUROHATUN','SERANGKAIAN PRIMER UNTUK DETEKSI GELATIN BABI DALAM PRODUK PERMEN','Paten',2019,'S00201909101','terdaftar','S00201909101','S00201909101',NULL),(8,1,NULL,'ANIS MASHDUROHATUN','KOLAGEN DARI KULIT KAMBING KACANG','Perlindungan Varietas Tanaman',2020,'S00201909101','granted','S00201909101','S00201909101',NULL),(10,112910,NULL,'HARIS WAHYUDI','MESIN KOMPUTER KONTROL NUMERIK ROUTER TIGA SUMBU PORTABEL','Paten',2005,'XXX','terdaftar','XXX','XXX',NULL);
/*!40000 ALTER TABLE `sikav_hki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_income_discount`
--

DROP TABLE IF EXISTS `sikav_income_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_income_discount` (
  `d_4` double(9,3) NOT NULL,
  `d_5` double(9,3) NOT NULL,
  `d_6` double(9,3) NOT NULL,
  `d_7` double(9,3) NOT NULL,
  `d_8` double(9,3) NOT NULL,
  `d_9` double(9,3) NOT NULL,
  `d_10` double(9,3) NOT NULL,
  `d_11` double(9,3) NOT NULL,
  `d_12` double(9,3) NOT NULL,
  `d_13` double(9,3) NOT NULL,
  `d_14` double(9,3) NOT NULL,
  `d_15` double(9,3) NOT NULL,
  `d_20` double(9,3) NOT NULL,
  `d_25` double(9,3) NOT NULL,
  `d_30` double(9,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_income_discount`
--

LOCK TABLES `sikav_income_discount` WRITE;
/*!40000 ALTER TABLE `sikav_income_discount` DISABLE KEYS */;
INSERT INTO `sikav_income_discount` VALUES (0.962,0.952,0.943,0.935,0.926,0.917,0.909,0.901,0.893,0.885,0.877,0.870,0.833,0.800,0.769),(0.925,0.907,0.890,0.873,0.857,0.842,0.826,0.812,0.797,0.783,0.769,0.756,0.694,0.640,0.592),(0.889,0.864,0.840,0.816,0.794,0.772,0.751,0.731,0.712,0.693,0.675,0.658,0.579,0.512,0.455),(0.855,0.823,0.792,0.763,0.735,0.708,0.683,0.659,0.636,0.613,0.592,0.572,0.482,0.410,0.350),(0.822,0.784,0.747,0.713,0.681,0.650,0.621,0.593,0.567,0.543,0.519,0.497,0.402,0.328,0.269),(0.790,0.746,0.705,0.666,0.630,0.596,0.564,0.535,0.507,0.480,0.456,0.432,0.335,0.262,0.207),(0.760,0.711,0.665,0.623,0.583,0.547,0.513,0.482,0.452,0.425,0.400,0.376,0.279,0.210,0.159),(0.731,0.677,0.627,0.582,0.540,0.502,0.467,0.434,0.404,0.376,0.351,0.327,0.233,0.168,0.123),(0.703,0.645,0.592,0.544,0.500,0.460,0.424,0.391,0.361,0.333,0.308,0.284,0.194,0.134,0.094),(0.676,0.614,0.558,0.508,0.463,0.422,0.386,0.352,0.322,0.295,0.270,0.247,0.162,0.107,0.073),(0.650,0.585,0.527,0.475,0.429,0.388,0.350,0.317,0.287,0.261,0.237,0.215,0.135,0.086,0.056),(0.625,0.557,0.497,0.444,0.397,0.356,0.319,0.286,0.257,0.231,0.208,0.187,0.112,0.069,0.043),(0.601,0.530,0.469,0.415,0.368,0.326,0.290,0.258,0.229,0.204,0.182,0.163,0.093,0.055,0.033),(0.577,0.505,0.442,0.388,0.340,0.299,0.263,0.232,0.205,0.181,0.160,0.141,0.078,0.044,0.025),(0.555,0.481,0.417,0.362,0.315,0.275,0.239,0.209,0.183,0.160,0.140,0.123,0.065,0.035,0.020),(0.534,0.458,0.394,0.339,0.292,0.252,0.218,0.188,0.163,0.141,0.123,0.107,0.054,0.028,0.015),(0.513,0.436,0.371,0.317,0.270,0.231,0.198,0.170,0.146,0.125,0.108,0.093,0.045,0.023,0.012),(0.494,0.416,0.350,0.296,0.250,0.212,0.180,0.153,0.130,0.111,0.095,0.081,0.038,0.018,0.009),(0.475,0.396,0.331,0.277,0.232,0.194,0.164,0.138,0.116,0.098,0.083,0.070,0.031,0.014,0.007),(0.456,0.377,0.312,0.258,0.215,0.178,0.149,0.124,0.104,0.087,0.073,0.061,0.026,0.012,0.005),(0.422,0.377,0.312,0.258,0.215,0.178,0.149,0.124,0.104,0.087,0.073,0.061,0.026,0.012,0.005),(0.422,0.342,0.278,0.226,0.184,0.150,0.123,0.101,0.083,0.068,0.056,0.046,0.018,0.007,0.003),(0.422,0.342,0.278,0.226,0.184,0.150,0.123,0.101,0.083,0.068,0.056,0.046,0.018,0.007,0.003),(0.390,0.310,0.247,0.197,0.158,0.126,0.102,0.082,0.066,0.053,0.043,0.035,0.013,0.005,0.002),(0.390,0.295,0.233,0.184,0.146,0.116,0.092,0.074,0.059,0.047,0.038,0.030,0.010,0.004,0.001),(0.375,0.295,0.233,0.184,0.146,0.116,0.092,0.074,0.059,0.047,0.038,0.030,0.010,0.004,0.001),(0.375,0.295,0.233,0.184,0.146,0.116,0.092,0.074,0.059,0.047,0.038,0.030,0.010,0.004,0.001),(0.375,0.295,0.233,0.184,0.146,0.116,0.092,0.074,0.059,0.047,0.038,0.030,0.010,0.004,0.001),(0.375,0.295,0.233,0.184,0.146,0.116,0.092,0.074,0.059,0.047,0.038,0.030,0.010,0.004,0.001),(0.308,0.231,0.174,0.131,0.099,0.075,0.057,0.044,0.033,0.026,0.020,0.015,0.004,0.001,0.001),(0.308,0.231,0.174,0.131,0.099,0.075,0.057,0.044,0.033,0.026,0.020,0.015,0.004,0.001,0.000),(0.308,0.231,0.174,0.131,0.099,0.075,0.057,0.044,0.033,0.026,0.020,0.015,0.004,0.001,0.000),(0.308,0.231,0.174,0.131,0.099,0.075,0.057,0.044,0.033,0.026,0.020,0.015,0.004,0.001,0.000),(0.308,0.231,0.174,0.131,0.099,0.075,0.057,0.044,0.033,0.026,0.020,0.015,0.004,0.001,0.000),(0.253,0.181,0.130,0.094,0.068,0.049,0.036,0.026,0.019,0.014,0.010,0.008,0.002,0.000,0.000),(0.253,0.181,0.130,0.094,0.068,0.049,0.036,0.026,0.019,0.014,0.010,0.008,0.002,0.000,0.000),(0.253,0.181,0.130,0.094,0.068,0.049,0.036,0.026,0.019,0.014,0.010,0.008,0.002,0.000,0.000),(0.253,0.181,0.130,0.094,0.068,0.049,0.036,0.026,0.019,0.014,0.010,0.008,0.002,0.000,0.000),(0.253,0.181,0.130,0.094,0.068,0.049,0.036,0.026,0.019,0.014,0.010,0.008,0.002,0.000,0.000),(0.208,0.142,0.097,0.067,0.046,0.032,0.022,0.015,0.011,0.008,0.005,0.004,0.001,0.000,0.000);
/*!40000 ALTER TABLE `sikav_income_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_income_hki`
--

DROP TABLE IF EXISTS `sikav_income_hki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_income_hki` (
  `hki_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sinta_id` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `nomor_permohonan` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `tahun_permohonan` year(4) DEFAULT NULL,
  `pemegang_paten` varchar(255) DEFAULT NULL,
  `inventor` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `no_publikasi` varchar(100) DEFAULT NULL,
  `tgl_publikasi` date DEFAULT NULL,
  `no_registrasi` varchar(100) DEFAULT NULL,
  `tgl_registrasi` date DEFAULT NULL,
  PRIMARY KEY (`hki_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_income_hki`
--

LOCK TABLES `sikav_income_hki` WRITE;
/*!40000 ALTER TABLE `sikav_income_hki` DISABLE KEYS */;
INSERT INTO `sikav_income_hki` VALUES (1,112910,NULL,NULL,'Paten','S00201803592','PROSES PENGUJIAN MIKRO FATIK',2018,'-','Dr. Ir. Haftirman, MEng.,Haris Wahyudi, ST. M.Sc,Nur Indah. S. ST., MT,Prof, (em) Dr. - Ing. Ir. Darwin Sebayang','granted','2017/S/00402','2017-07-07','IDS000002940','2020-03-03'),(2,112910,NULL,NULL,'Paten','P00201802912','ALAT KERJA MULTI FUNGSI BERBASIS BUSUR PLASMA',2018,'-','ARBI DIMYATI,DARWIN SEBAYANG,HARIS WAHYUDI,HENDI SARYANTO','granted','2018/11550','2018-10-25','IDP000067783','2020-02-28'),(3,112910,NULL,32606,'paten','P00201707747','MESIN KOMPUTER KONTROL NUMERIK ROUTER TIGA SUMBU PORTABEL',2017,'','Darwin Sebayang,Haris Wahyudi,Julpri Andika,Sugiarto','','2018/05446','2018-05-25','IDP000057134','2019-03-12'),(4,112910,NULL,35309,'paten','P00201902221','TEKNIK PENGEMBANGAN NANO MATERIAL PADUAN FEMN',2019,'','DARWIN SEBAYANG,HARIS WAHYUDI,HENDI SARYANTO,KONTAN TARIGAN','','2019/07101','2019-09-27','','0000-00-00'),(5,112910,NULL,35322,'paten','S00201701825','SISTEM PERALATAN PENGUJIAN MIKRO FATIK',2017,'','Darwin Sebayang,Haftirman,Haris Wahyudi,Nur Indah','','2017/S/00402','2017-07-07','IDS000001859','2018-05-30'),(6,112910,NULL,35326,'paten','S00201701826','PANEL PRAKTIKUM 2 (DUA)SISI PNEUMATIK/HIDROLIK',2017,'','DARWIN SEBAYANG,HAFTIRMAN,HARIS WAHYUDI,I GUSTI AYU ARWATI,NUR INDAH','','2017/S/00398','2017-07-07','IDS000001842','2018-05-17'),(7,112910,NULL,35330,'paten','P00201802912','ALAT KERJA MULTI FUNGSI BERBASIS BUSUR PLASMA',2018,'','ARBI DIMYATI,DARWIN SEBAYANG,HARIS WAHYUDI,HENDI SARYANTO','','2018/11550','2018-10-25','IDP000067783','2020-02-28'),(8,112910,NULL,35332,'paten','S00201803592','PROSES PENGUJIAN MIKRO FATIK',2018,'','Dr. Ir. Haftirman, MEng.,Haris Wahyudi, ST. M.Sc,Nur Indah. S. ST., MT,Prof, (em) Dr. - Ing. Ir. Darwin Sebayang','','2017/S/00402','2017-07-07','IDS000002940','2020-03-03'),(9,1,NULL,NULL,'Paten','1234567890','test\">[removed]alert&#40;\'test\'&#41;[removed]',2019,'test','test','terdaftar','1234567890','2019-03-01','123456789','2020-02-27'),(10,1,NULL,NULL,'Paten Sederhana','1234','test\">[removed]alert&#40;\'test\'&#41;[removed]',2020,'test\">[removed]alert&#40;\'test\'&#41;[removed]','1234','terdaftar','1234','2021-04-01','1234','2021-04-07'),(11,1,NULL,NULL,'Paten','12345','test12345\">[removed]alert&#40;\'test\'&#41;[removed]',0000,'12345\">[removed]alert&#40;\'test\'&#41;[removed]','12345\">[removed]alert&#40;\'test\'&#41;[removed]','terdaftar','12345','2021-03-31','12345','2021-04-08');
/*!40000 ALTER TABLE `sikav_income_hki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_income_kalkulasi`
--

DROP TABLE IF EXISTS `sikav_income_kalkulasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_income_kalkulasi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sinta_id` bigint(20) DEFAULT NULL,
  `hki_id` bigint(20) NOT NULL,
  `hki_inventor` text,
  `hki_judul` varchar(255) DEFAULT NULL,
  `periode` int(9) DEFAULT NULL,
  `modal` double(20,2) DEFAULT NULL,
  `sukubunga` decimal(20,2) DEFAULT NULL,
  `marketsize` double(20,2) DEFAULT '0.00',
  `marketshare` char(10) DEFAULT '',
  `pagu_maksimal` double(20,2) DEFAULT '0.00',
  `discount_factor` double(9,2) DEFAULT NULL,
  `target` double(9,2) DEFAULT NULL,
  `marketshare_persen` double(9,2) DEFAULT NULL,
  `qty_tahun1` double(9,2) DEFAULT NULL,
  `marketshare_tahun2` decimal(20,2) DEFAULT NULL,
  `biaya_cogs` double(20,2) DEFAULT NULL,
  `harga_tahun1` double(20,2) DEFAULT NULL,
  `harga_tahun2` double(20,2) DEFAULT NULL,
  `biaya_investasi` double(20,2) DEFAULT NULL,
  `biaya_riset` double(20,2) DEFAULT NULL,
  `biaya_lisensi` double(20,2) DEFAULT NULL,
  `persen_lisensi` double(20,2) DEFAULT NULL,
  `biaya_tetap` double(20,2) DEFAULT NULL,
  `biaya_marketing` double(20,2) DEFAULT NULL,
  `biaya_perawatan` double(20,2) DEFAULT NULL,
  `biaya_warehouse` double(20,2) DEFAULT NULL,
  `biaya_depresiasi` double(20,2) DEFAULT NULL,
  `nilai_npv` double(20,2) DEFAULT NULL,
  `item_cogs` text,
  `item_harga` text,
  `item_fcost` text,
  `item_investasi` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_income_kalkulasi`
--

LOCK TABLES `sikav_income_kalkulasi` WRITE;
/*!40000 ALTER TABLE `sikav_income_kalkulasi` DISABLE KEYS */;
INSERT INTO `sikav_income_kalkulasi` VALUES (1,112910,1,'Dr. Ir. Haftirman, MEng.,Haris Wahyudi, ST. M.Sc,Nur Indah. S. ST., MT,Prof, (em) Dr. - Ing. Ir. Darwin Sebayang','PROSES PENGUJIAN MIKRO FATIK',5,18000000000.00,11.00,1000000.00,'persen2',150000.00,10.00,3600.00,50.00,1800.00,90.00,35547200.00,49766080.00,103.00,7978592000.00,2596000000.00,100000000.00,15.00,1371946666.00,5.00,20000000.00,300000000.00,997324000.00,30187681124.96,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sikav_income_kalkulasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_inflasi_info`
--

DROP TABLE IF EXISTS `sikav_inflasi_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_inflasi_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_inflasi_info`
--

LOCK TABLES `sikav_inflasi_info` WRITE;
/*!40000 ALTER TABLE `sikav_inflasi_info` DISABLE KEYS */;
INSERT INTO `sikav_inflasi_info` VALUES (1,'https://www.bi.go.id/id/moneter/inflasi/data/Default.aspx','2020-11-01 16:04:41');
/*!40000 ALTER TABLE `sikav_inflasi_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sikav_users`
--

DROP TABLE IF EXISTS `sikav_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sikav_users` (
  `id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sikav_users`
--

LOCK TABLES `sikav_users` WRITE;
/*!40000 ALTER TABLE `sikav_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `sikav_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:23
