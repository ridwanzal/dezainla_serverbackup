-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: pd_rexpo_backup1
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `pd_rexpo_backup1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pd_rexpo_backup1` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `pd_rexpo_backup1`;

--
-- Table structure for table `rexpo_account`
--

DROP TABLE IF EXISTS `rexpo_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_card` varchar(128) DEFAULT NULL,
  `id_card_type` varchar(128) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `username` varchar(128) DEFAULT NULL,
  `nim` varchar(128) NOT NULL COMMENT 'Nomor Induk Mahasiswa',
  `nama` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `tempat_lahir` varchar(256) DEFAULT NULL,
  `account_type` enum('admin','peserta','perusahaan','konsultan','psikologis') NOT NULL DEFAULT 'peserta',
  `namafile` text,
  `pendidikan` enum('d3','s1','s2','s3') DEFAULT NULL,
  `id_prodi` int(11) NOT NULL,
  `universitas` varchar(256) DEFAULT NULL,
  `fakultas` varchar(256) DEFAULT NULL,
  `jurusan` varchar(128) DEFAULT NULL,
  `tahun_lulus` int(5) DEFAULT NULL,
  `comp_bidang_usaha` text,
  `comp_deskripsi` text,
  `comp_website` varchar(256) DEFAULT NULL,
  `comp_contact_person` bigint(20) DEFAULT NULL,
  `comp_alamat` text NOT NULL,
  `date_created` date DEFAULT NULL,
  `date_updated` date DEFAULT NULL,
  `time_created` time DEFAULT NULL,
  `time_updated` time DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT '0 - inactive\r\n1 - active confirm\r\n2 - banned',
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `username` (`username`),
  KEY `phone` (`phone`),
  KEY `universitas` (`universitas`),
  KEY `pendidikan` (`pendidikan`),
  KEY `fakultas` (`fakultas`),
  KEY `jurusan` (`jurusan`),
  KEY `tahun_lulus` (`tahun_lulus`),
  KEY `status` (`status`),
  KEY `nim` (`nim`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_account`
--

LOCK TABLES `rexpo_account` WRITE;
/*!40000 ALTER TABLE `rexpo_account` DISABLE KEYS */;
INSERT INTO `rexpo_account` VALUES (37,NULL,NULL,'admin@cdcunsri.ac.id',NULL,'','M. Ridwan Zalbina','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'admin',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2021-06-18','2021-06-18','14:07:24','14:07:24',1),(38,NULL,NULL,'zalbinaridwan@gmail.com',NULL,'','M. Ridwan Zalbina','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta','319260_264330180279715_34534445_n2.jpg',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2021-06-18','2021-06-18','14:09:08','14:09:08',1),(39,NULL,NULL,'mridwanzalbina@gmail.com',NULL,'','M Ridwan Zalbina','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2021-06-19','2021-06-19','07:42:21','07:42:21',1),(40,NULL,NULL,'merka@gmail.com',NULL,'','Merka Nika','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2021-06-20','2021-06-20','10:32:33','10:32:33',1),(41,NULL,NULL,'mina@gmail.com',NULL,'','Mina Sia','25d55ad283aa400af464c76d713c07ad',NULL,NULL,NULL,'peserta',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2021-06-20','2021-06-20','10:33:35','10:33:35',1);
/*!40000 ALTER TABLE `rexpo_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_account_activity`
--

DROP TABLE IF EXISTS `rexpo_account_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_account_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activity` enum('login','registration','logout') NOT NULL,
  `ip_address_visitor` varchar(64) NOT NULL,
  `browser_type` varchar(256) NOT NULL,
  `os` varchar(256) NOT NULL,
  `date_created` date NOT NULL,
  `time_created` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `activity` (`activity`),
  KEY `browser_type` (`browser_type`),
  KEY `os` (`os`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_account_activity`
--

LOCK TABLES `rexpo_account_activity` WRITE;
/*!40000 ALTER TABLE `rexpo_account_activity` DISABLE KEYS */;
INSERT INTO `rexpo_account_activity` VALUES (1,19,'','login','::1','','','2021-06-13','18:00:05'),(2,19,'','login','::1','','','2021-06-13','18:01:16'),(3,19,'','login','::1','','','2021-06-13','18:02:20'),(4,16,'','login','::1','','','2021-06-13','19:30:02'),(5,19,'','login','::1','','','2021-06-13','19:54:00'),(6,34,'taufik20@gmail.com','registration','::1','','','2021-06-13','20:33:35'),(7,19,'','login','::1','','','2021-06-13','20:33:48'),(8,19,'','login','::1','','','2021-06-13','20:39:38'),(9,35,'abdibimantara@gmail.com','registration','::1','','','2021-06-13','20:40:23'),(10,19,'','login','::1','','','2021-06-13','20:45:22'),(11,19,'','login','::1','','','2021-06-13','21:01:20'),(12,19,'','login','::1','Google Chrome','','2021-06-13','21:03:58'),(13,19,'','logout','::1','Google Chrome','','2021-06-13','21:07:14'),(14,19,'','login','::1','Google Chrome','','2021-06-13','21:07:22'),(15,19,'','logout','::1','Google Chrome','','2021-06-13','21:10:23'),(16,19,'','login','::1','Google Chrome','linux','2021-06-13','21:11:58'),(17,19,'','logout','::1','Google Chrome','linux','2021-06-13','21:28:32'),(18,16,'','login','::1','Google Chrome','linux','2021-06-13','21:28:51'),(19,16,'','logout','::1','Google Chrome','linux','2021-06-13','21:29:05'),(20,16,'','login','::1','Google Chrome','linux','2021-06-13','21:32:06'),(21,16,'','logout','::1','Google Chrome','linux','2021-06-13','22:40:52'),(22,19,'','login','::1','Google Chrome','linux','2021-06-13','22:40:59'),(23,19,'','login','::1','Google Chrome','linux','2021-06-14','13:41:49'),(24,19,'','logout','::1','Google Chrome','linux','2021-06-14','13:56:11'),(25,16,'','login','::1','Google Chrome','linux','2021-06-14','14:04:50'),(26,16,'','logout','::1','Google Chrome','linux','2021-06-14','14:06:34'),(27,16,'','login','::1','Google Chrome','linux','2021-06-14','14:32:17'),(28,16,'','logout','::1','Google Chrome','linux','2021-06-14','14:34:40'),(29,16,'','login','::1','Google Chrome','linux','2021-06-14','14:54:21'),(30,19,'','login','::1','Google Chrome','linux','2021-06-14','18:03:10'),(31,19,'','logout','::1','Google Chrome','linux','2021-06-14','18:04:44'),(32,16,'','login','::1','Google Chrome','linux','2021-06-14','18:33:18'),(33,16,'','login','::1','Google Chrome','linux','2021-06-14','22:04:05'),(34,36,'merka@gmail.com','registration','::1','Google Chrome','linux','2021-06-15','09:22:38'),(35,19,'','login','::1','Google Chrome','linux','2021-06-15','13:46:43'),(36,19,'','login','::1','Google Chrome','linux','2021-06-15','20:00:33'),(37,16,'','login','::1','Google Chrome','linux','2021-06-16','08:47:38'),(38,16,'','logout','::1','Google Chrome','linux','2021-06-16','08:55:00'),(39,19,'','login','::1','Google Chrome','linux','2021-06-16','08:55:14'),(40,19,'','logout','::1','Google Chrome','linux','2021-06-16','09:09:14'),(41,19,'','login','::1','Google Chrome','linux','2021-06-16','09:09:24'),(42,19,'','logout','::1','Google Chrome','linux','2021-06-16','09:38:44'),(43,16,'','logout','::1','Google Chrome','linux','2021-06-16','09:53:43'),(44,16,'','login','::1','Google Chrome','linux','2021-06-16','10:53:53'),(45,16,'','logout','::1','Google Chrome','linux','2021-06-16','10:54:31'),(46,19,'','login','::1','Google Chrome','linux','2021-06-16','11:15:45'),(47,19,'','logout','::1','Google Chrome','linux','2021-06-16','11:34:57'),(48,19,'','login','::1','Google Chrome','linux','2021-06-16','11:35:11'),(49,19,'','logout','::1','Google Chrome','linux','2021-06-16','12:57:04'),(50,19,'','login','::1','Google Chrome','linux','2021-06-16','13:03:29'),(51,19,'','logout','::1','Google Chrome','linux','2021-06-16','13:07:31'),(52,19,'','login','::1','Google Chrome','linux','2021-06-16','13:07:40'),(53,19,'','logout','::1','Google Chrome','linux','2021-06-16','13:10:25'),(54,19,'','login','::1','Google Chrome','linux','2021-06-16','13:11:22'),(55,19,'','logout','::1','Google Chrome','linux','2021-06-16','14:05:11'),(56,19,'','login','::1','Google Chrome','linux','2021-06-16','14:10:19'),(57,19,'','logout','::1','Google Chrome','linux','2021-06-16','14:10:34'),(58,19,'','login','::1','Google Chrome','linux','2021-06-17','06:48:17'),(59,19,'','logout','::1','Google Chrome','linux','2021-06-17','06:52:02'),(60,19,'','login','::1','Google Chrome','linux','2021-06-17','07:06:09'),(61,19,'','logout','::1','Google Chrome','linux','2021-06-17','08:33:02'),(62,19,'','login','::1','Google Chrome','linux','2021-06-17','08:33:40'),(63,19,'','logout','::1','Google Chrome','linux','2021-06-17','09:14:22'),(64,16,'','login','::1','Google Chrome','linux','2021-06-17','09:14:39'),(65,16,'','logout','::1','Google Chrome','linux','2021-06-17','09:14:43'),(66,16,'','login','::1','Google Chrome','linux','2021-06-17','09:22:08'),(67,16,'','logout','::1','Google Chrome','linux','2021-06-17','09:22:11'),(68,19,'','login','::1','Google Chrome','linux','2021-06-17','09:22:52'),(69,19,'','login','::1','Google Chrome','linux','2021-06-17','15:13:05'),(70,19,'','logout','::1','Google Chrome','linux','2021-06-17','15:13:24'),(71,16,'','login','::1','Google Chrome','linux','2021-06-17','19:21:48'),(72,16,'','logout','::1','Google Chrome','linux','2021-06-17','19:24:53'),(73,16,'','login','::1','Google Chrome','linux','2021-06-17','19:42:33'),(74,16,'','logout','::1','Google Chrome','linux','2021-06-17','20:33:14'),(75,16,'','login','::1','Google Chrome','linux','2021-06-17','20:33:24'),(76,16,'','logout','::1','Google Chrome','linux','2021-06-17','20:33:31'),(77,16,'','login','::1','Google Chrome','linux','2021-06-17','20:51:16'),(78,16,'','logout','::1','Google Chrome','linux','2021-06-17','20:53:44'),(79,19,'','login','::1','Google Chrome','linux','2021-06-17','20:53:51'),(80,19,'','logout','::1','Google Chrome','linux','2021-06-17','20:57:51'),(81,19,'','login','::1','Google Chrome','linux','2021-06-17','21:09:51'),(82,19,'','logout','::1','Google Chrome','linux','2021-06-17','21:09:54'),(83,16,'','login','::1','Google Chrome','linux','2021-06-17','21:10:31'),(84,16,'','logout','::1','Google Chrome','linux','2021-06-17','21:11:16'),(85,19,'','login','::1','Google Chrome','linux','2021-06-17','21:13:50'),(86,19,'','logout','::1','Google Chrome','linux','2021-06-17','21:14:09'),(87,19,'','login','::1','Google Chrome','linux','2021-06-17','21:22:07'),(88,19,'','logout','::1','Google Chrome','linux','2021-06-17','21:25:20'),(89,19,'','login','::1','Google Chrome','linux','2021-06-18','11:08:07'),(90,19,'','logout','::1','Google Chrome','linux','2021-06-18','11:13:33'),(91,16,'','login','::1','Google Chrome','linux','2021-06-18','11:13:42'),(92,16,'','logout','::1','Google Chrome','linux','2021-06-18','11:22:41'),(93,16,'','login','::1','Google Chrome','linux','2021-06-18','11:39:06'),(94,16,'','logout','::1','Google Chrome','linux','2021-06-18','13:08:55'),(95,37,'admin@cdcunsri.ac.id','registration','::1','Google Chrome','linux','2021-06-18','14:07:24'),(96,37,'','login','::1','Google Chrome','linux','2021-06-18','14:08:05'),(97,37,'','logout','::1','Google Chrome','linux','2021-06-18','14:08:21'),(98,37,'','login','::1','Google Chrome','linux','2021-06-18','14:08:29'),(99,37,'','logout','::1','Google Chrome','linux','2021-06-18','14:08:35'),(100,38,'zalbinaridwan@gmail.com','registration','::1','Google Chrome','linux','2021-06-18','14:09:08'),(101,37,'','login','::1','Google Chrome','linux','2021-06-18','14:13:19'),(102,37,'','logout','::1','Google Chrome','linux','2021-06-18','14:13:42'),(103,38,'','login','::1','Google Chrome','linux','2021-06-18','14:13:51'),(104,38,'','login','::1','Google Chrome','linux','2021-06-19','07:30:14'),(105,38,'','logout','::1','Google Chrome','linux','2021-06-19','07:39:38'),(106,39,'mridwanzalbina@gmail.com','registration','::1','Google Chrome','linux','2021-06-19','07:42:21'),(107,37,'','login','::1','Google Chrome','linux','2021-06-19','07:46:17'),(108,37,'','logout','::1','Google Chrome','linux','2021-06-19','07:46:24'),(109,39,'','login','::1','Google Chrome','linux','2021-06-19','07:46:34'),(110,38,'','login','::1','Google Chrome','linux','2021-06-19','19:00:38'),(111,38,'','login','::1','Google Chrome','linux','2021-06-20','05:29:43'),(112,38,'','logout','::1','Google Chrome','linux','2021-06-20','07:38:54'),(113,38,'','login','::1','Google Chrome','linux','2021-06-20','08:01:56'),(114,38,'','logout','::1','Google Chrome','linux','2021-06-20','08:25:42'),(115,38,'','login','::1','Google Chrome','linux','2021-06-20','08:36:46'),(116,38,'','logout','::1','Google Chrome','linux','2021-06-20','10:25:18'),(117,39,'','login','::1','Google Chrome','linux','2021-06-20','10:25:41'),(118,39,'','logout','::1','Google Chrome','linux','2021-06-20','10:28:34'),(119,38,'','login','::1','Google Chrome','linux','2021-06-20','10:28:44'),(120,38,'','logout','::1','Google Chrome','linux','2021-06-20','10:32:17'),(121,40,'merka@gmail.com','registration','::1','Google Chrome','linux','2021-06-20','10:32:33'),(122,41,'mina@gmail.com','registration','::1','Google Chrome','linux','2021-06-20','10:33:35'),(123,37,'','login','::1','Google Chrome','linux','2021-06-20','10:34:00'),(124,37,'','logout','::1','Google Chrome','linux','2021-06-20','10:34:10'),(125,40,'','login','::1','Google Chrome','linux','2021-06-20','10:34:20'),(126,40,'','logout','::1','Google Chrome','linux','2021-06-20','10:39:33'),(127,38,'','login','::1','Google Chrome','linux','2021-06-20','10:39:55'),(128,38,'','logout','::1','Google Chrome','linux','2021-06-20','10:44:19'),(129,40,'','login','::1','Google Chrome','linux','2021-06-20','10:44:35'),(130,40,'','logout','::1','Google Chrome','linux','2021-06-20','10:44:41'),(131,41,'','login','::1','Google Chrome','linux','2021-06-20','10:44:47'),(132,41,'','logout','::1','Google Chrome','linux','2021-06-20','10:51:30'),(133,38,'','login','::1','Google Chrome','linux','2021-06-20','10:56:50'),(134,38,'','logout','::1','Google Chrome','linux','2021-06-20','13:04:47'),(135,38,'','login','::1','Google Chrome','linux','2021-06-20','13:14:13'),(136,38,'','login','::1','Google Chrome','linux','2021-06-21','05:47:09'),(137,38,'','logout','::1','Google Chrome','linux','2021-06-21','06:17:28'),(138,38,'','login','::1','Google Chrome','linux','2021-06-21','06:34:48'),(139,38,'','logout','::1','Google Chrome','linux','2021-06-21','06:34:54'),(140,40,'','login','::1','Google Chrome','linux','2021-06-21','06:40:22'),(141,40,'','logout','::1','Google Chrome','linux','2021-06-21','06:42:19'),(142,38,'','login','::1','Google Chrome','linux','2021-06-21','06:43:45'),(143,38,'','logout','::1','Google Chrome','linux','2021-06-21','09:20:35'),(144,37,'','login','::1','Google Chrome','linux','2021-06-21','09:20:42');
/*!40000 ALTER TABLE `rexpo_account_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_apply`
--

DROP TABLE IF EXISTS `rexpo_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id auto increments',
  `account_id` bigint(20) NOT NULL,
  `company_id` bigint(20) NOT NULL,
  `vacancy_id` bigint(20) NOT NULL,
  `date_created` date NOT NULL,
  `time_created` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `company_id` (`company_id`),
  KEY `vacancy_id` (`vacancy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_apply`
--

LOCK TABLES `rexpo_apply` WRITE;
/*!40000 ALTER TABLE `rexpo_apply` DISABLE KEYS */;
INSERT INTO `rexpo_apply` VALUES (2,16,26,1,'2021-04-20','16:36:27'),(3,16,26,2,'2021-04-20','16:36:58'),(4,24,26,5,'2021-04-20','17:01:50'),(5,16,26,1,'2021-04-20','17:10:45'),(6,16,26,1,'2021-06-11','16:58:34');
/*!40000 ALTER TABLE `rexpo_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_dropcv`
--

DROP TABLE IF EXISTS `rexpo_dropcv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_dropcv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `namafile` text NOT NULL,
  `basepath` text NOT NULL,
  `date_created` date DEFAULT NULL,
  `date_updated` date NOT NULL,
  `time_created` time DEFAULT NULL,
  `time_updated` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dropcv_to_account` (`account_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `dropcv_to_account` FOREIGN KEY (`account_id`) REFERENCES `rexpo_account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_dropcv`
--

LOCK TABLES `rexpo_dropcv` WRITE;
/*!40000 ALTER TABLE `rexpo_dropcv` DISABLE KEYS */;
/*!40000 ALTER TABLE `rexpo_dropcv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_files`
--

DROP TABLE IF EXISTS `rexpo_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `forms_id` int(11) NOT NULL,
  `filename` text NOT NULL,
  `type` enum('image','video','docs') NOT NULL,
  `date_created` date NOT NULL,
  `date_updated` date NOT NULL,
  `time_created` time NOT NULL,
  `time_updated` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_id` (`forms_id`),
  KEY `account_id` (`account_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_files`
--

LOCK TABLES `rexpo_files` WRITE;
/*!40000 ALTER TABLE `rexpo_files` DISABLE KEYS */;
INSERT INTO `rexpo_files` VALUES (4,38,22,'2.png','image','2021-06-20','2021-06-20','08:18:43','08:18:43'),(5,38,23,'image1_1.png','image','2021-06-20','2021-06-20','10:03:36','10:03:36'),(6,38,24,'scp2.png','image','2021-06-20','2021-06-20','10:24:28','10:24:28'),(7,39,25,'scp21.png','image','2021-06-20','2021-06-20','10:26:33','10:26:33'),(8,40,27,'header1.png','image','2021-06-20','2021-06-20','10:34:46','10:34:46'),(9,41,28,'Screenshot_from_2021-04-21_19-30-48.png','image','2021-06-20','2021-06-20','10:49:28','10:49:28'),(10,38,26,'Screenshot_from_2021-04-21_19-30-48.png','image','2021-06-20','2021-06-20','10:49:28','10:49:28'),(11,38,29,'exhibition-booth-3d-composition_1284-18490.jpg','image','2021-06-20','2021-06-20','12:24:37','12:24:37'),(12,38,30,'social-thumbnail.jpg','image','2021-06-21','2021-06-21','07:06:16','07:06:16'),(13,38,31,'3.png','image','2021-06-21','2021-06-21','07:09:54','07:09:54'),(14,38,32,'Banner-2.png','image','2021-06-21','2021-06-21','07:12:42','07:12:42'),(15,38,33,'4.png','image','2021-06-21','2021-06-21','07:14:29','07:14:29'),(16,38,34,'135648711-touch-screen-kiosk-icon-isometric-of-touch-screen-kiosk-vector-icon-for-web-design-isolated-on-white-removebg-preview.png','image','2021-06-21','2021-06-21','07:16:04','07:16:04'),(17,38,35,'5.png','image','2021-06-21','2021-06-21','09:03:48','09:03:48'),(18,38,35,'6.png','image','2021-06-21','2021-06-21','09:03:48','09:03:48'),(19,38,35,'11.png','image','2021-06-21','2021-06-21','09:03:48','09:03:48'),(20,38,35,'41.png','image','2021-06-21','2021-06-21','09:03:48','09:03:48');
/*!40000 ALTER TABLE `rexpo_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_forms`
--

DROP TABLE IF EXISTS `rexpo_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `judul` varchar(256) NOT NULL,
  `deskripsi` text NOT NULL,
  `kategori` varchar(256) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `date_updated` date NOT NULL,
  `time_created` time NOT NULL,
  `time_updated` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `judul` (`judul`),
  KEY `likes` (`likes`),
  KEY `kategori` (`kategori`),
  KEY `id_prodi` (`id_prodi`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_forms`
--

LOCK TABLES `rexpo_forms` WRITE;
/*!40000 ALTER TABLE `rexpo_forms` DISABLE KEYS */;
INSERT INTO `rexpo_forms` VALUES (22,38,'Payload recognition and detection of Cross Site Scripting attack','Web Application becomes the leading solution for the utilization of systems that need access globally, distributed, cost-effective, as well as the diversity of the content that can run on this technology. At the same time web application security have always been a major issue that must be considered due to the fact that 60% of Internet attacks targeting web application platform. One of the biggest impacts on this technology is Cross Site Scripting (XSS) attack, the most frequently occurred and are always in the TOP 10 list of Open Web Application Security Project (OWASP). Vulnerabilities in this attack occur in the absence of checking, testing, and the attention about secure coding practices. There are several alternatives to prevent the attacks that associated with this threat. Network Intrusion Detection System can be used as one solution to prevent the influence of XSS Attack. This paper investigates the XSS attack recognition and detection using regular expression pattern matching and a preprocessing method. Experiments are conducted on a testbed with the aim to reveal the behaviour of the attack.','',3,0,'2021-06-20','2021-06-20','08:18:43','08:18:43'),(23,38,'QoS Menggunakan Metode Regresi Pada Jaringan Delay Tolerant Network (DTN)','Delay tolerant network merupakan arsitektur jaringan end-to-end yang didesain untuk menyediakan solusi komunikasi pada lingkungan yang memiliki konektivitas yang terputus-putus, long delay, dan kesalahan rate yang tinggi. DTN menyediakan model komunikasi store-carry and forward packet switching yaitu model komunikasi yang mengirimkan data berupa bundle yang dapat disimpan dan diteruskan oleh DTN. Penelitian dilakukan untuk menghitung kualitas layanan dalam proses pengiriman data yang dikumpulkan diolah menggunakan parameter QoS yaitu delay, throughput, packet loss, kemudian dianalisa dan diuji pengaruhnya terhadap variabel-variabel lainnya menggunakan metode analisis regresi. Berdasarkan data dari hasil pengujian diketahui bahwa delay rata-rata dikategorikan buruk karena berada pada rentang lebih kecil dari 450 ms, kualitas throughput dikategorikan lebih baik karena berada pada rentang 1,2 Mbps keatas dan nilai packet loss yang di peroleh dari penelitian dikategorikan sebagai kualitas layanan data sangat baik karena berada pada rentang 0% sampai 3%. Hasil analisis regresi dilihat dari hasil korelasi person menunjukan bahwa variabel delay, throughput, packet loss berpengaruh signifikan terhadap persentase keberhasilan pengiriman data dan hubungan antar variabel sangat kuat.','',3,0,'2021-06-20','2021-06-20','10:03:36','10:03:36'),(24,38,'Web Services Attacks and Security- A Systematic Literature Review','Web Services allow applications to communicate with each other independent of platform and/or language. They are prone to attacks in the form of Denial-Of-Service, XML, XPath, SQL injection and spoofing, making implementation of web service security vital. Though many solutions are proposed for minimizing attacks, there is no single solution for mitigating all the attacks on web services. The objective of this paper is to present a systematic review on the studies of web service security. It is identified that there is lot of research going on in web services, dealing mostly with attack detection as well as identification of vulnerabilities in the services. Denial-of-service attack is found to be the most addressed of all attacks. Solutions were mainly proposed using dynamic analysis, closely followed by static analysis.','',3,0,'2021-06-20','2021-06-20','10:24:28','10:24:28'),(25,39,'Web Services Based On SOAP and REST Principles','Interest in Web services is rapidly increased from\r\ntheir start of use. To exchange information among the application in standard way is the main goal of web services. This communication between the applications is based on SOAP and REST principle. SOAP communications causes network traffic, higher latency and processing delays. To overcome this limitations the REST’ful architecture is used. REST is a lightweight, easy and better alternative for the SOAP. In this paper comparison on performance of SOAP based and REST’ful web services based on different metric for mobile environment and multimedia conference is taken into consideration.\r\nIndex','',3,0,'2021-06-20','2021-06-20','10:26:33','10:26:33'),(26,38,'Framework of Intrusion Detection System via Snort Application on Campus Network Environment','In this research, we propose an\r\narchitectural solution to implement the Intrusion Detection System &#40;IDS&#41; via snort in campus network environment. Intrusion Detection System &#40;IDS&#41; via snort application has become a discussion issue for this\r\ntime being. The objective of this\r\nimplementation is to measure and detect the malware on snort application over Local Area Network (LAN). Virtual Private Network (VPN) technology has become a discussion issue for this time being. Today, the deployment of this IDS technology on an organization truly can give a great privacy and security benefit over campus environment. This study focuses on installation, configuring and implementation of snort in University of Kuala Lumpur network environment. In addition, we emphasis on access to a MySQL database, WINCAP and Perl scripts (PHP). Based on the finding result, the IDS over snort application is able to analyze and detect malware activity in client server environment over LAN.','',3,0,'2021-06-20','2021-06-20','10:31:42','10:31:42'),(27,40,'Investigtation on Security System for SNORT-Based Campus Network','With the rapid development of Internet, it is an important task to ensure that college students accessing the Internet in a healthy way. This paper discusses the monitoring of user behavior by means of SNORT software in order to establish a campus network security monitoring system.\r\nKey','',3,0,'2021-06-20','2021-06-20','10:34:46','10:34:46'),(28,41,'Hunting Cross-Site Scripting Attacks in the Network Elias','Cross-site Scripting (XSS) attacks in web applications are considered a major threat. In a yearly basis, large IT security vendors export statistics that highlight the need for designing and implementing more efficient countermeasures for secur- ing modern web applications and web users. So far, all these studies are carried out by IT security vendors. The academic community lacks of the tools for performing similar studies for quantifying various properties ofXSS attacks.','',3,0,'2021-06-20','2021-06-20','10:49:28','10:49:28'),(29,38,'An Online and Adaptive Signature-based Approach for Intrusion Detection Using Learning Classifier Systems','This thesis presents the case of dynamically and adaptively learning signatures for network intrusion detection using genetic based machine learning techniques. The two major criticisms of the signature based intrusion detection systems are their i) reliance on domain experts to handcraft intrusion signatures and ii) inability to detect previously unknown attacks or the attacks for which no signatures are available at the time.','',3,0,'2021-06-20','2021-06-20','12:24:37','12:24:37'),(30,38,'A survey on gaps, threat remediation challenges and some thoughts for proactive attack detection in cloud computing','The long-term potential benefits through reduction of cost of services and improvement of business outcomes make Cloud Computing an attractive proposition these days. To make it more marketable in the wider IT user community one needs to address a variety of information security risks. In this paper, we present an extensive review on cloud computing with the main focus on gaps and security concerns. We identify the top security threats and their existing solutions. We also investigate the challenges/obstacles in implementing threat remediation. To address these issues, we propose a proactive threat detection model by adopting three main goals: (i) detect an attack when it happens, (ii) alert related parties (system admin, data owner) about the attack type and take combating action, and (iii) generate information on the type of attack by analyzing the pattern (even if the cloud provider attempts subreption). To emphasize the importance of monitoring cyber attacks we provide a brief overview of existing literature on cloud computing security.','',3,0,'2021-06-21','2021-06-21','07:06:16','07:06:16'),(31,38,'A Taxonomy of Botnet Detection Techniques Hossein','Among the diverse forms of malware, Botnet is the most widespread and serious threat which occurs commonly in today\'s cyber attacks. Botnets are collections of compromised computers which are remotely controlled by its originator (BotMaster) under a common Commond-and-Control (C&C) infrastructure. They provide a distributed platform for several illegal activities such as launching distributed denial of service (DDOS) attacks against critical targets, malware distribution, phishing, and click fraud','',3,0,'2021-06-21','2021-06-21','07:09:54','07:09:54'),(32,38,'Automatic XSS detection and Snort signatures/ ACLs generation by the means of a cloud-based honeypot system','It is no secret that nowadays cloud computing is becoming popular with large companies, mainly because they can share valuable resources in a cost effective way. This is just the beginning of the cloud computing, an independent research firm “Forrester Research” expects the global cloud computing market to grow from $40.7 billion in 2011 to more than $241 billion in 2020 (Ried, et al., April 2011). This increasing migration towards cloud computing is resulting in an escalation of security threats, which is becoming a major issue. The cloud computing is even considered to be a “security nightmare», according to John Chambers, Cisco CEO (McMillan, 2009)','',3,0,'2021-06-21','2021-06-21','07:12:42','07:12:42'),(33,38,'A Database of Computer Attacks for the Evaluation of Intrusion Detection Systems','The 1998 DARPA intrusion detection evaluation created the first standard corpus for evaluating computer intrusion detection systems. This corpus was designed to evaluate both false alarm rates and detection rates of intrusion detection systems using many types of both known and new attacks embedded in a large amount of normal background traffic. The corpus was collected from a simulation network that was used to automatically generate realistic traffic—including attempted attacks.','',3,0,'2021-06-21','2021-06-21','07:14:29','07:14:29'),(34,38,'Hunting Cross-Site Scripting Attacks in the Network Elias','Cross-site Scripting (XSS) attacks in web applications are considered a major threat. In a yearly basis, large IT security vendors export statistics that highlight the need for designing and implementing more efficient countermeasures for secur- ing modern web applications and web users. So far, all these studies are carried out by IT security vendors. The academic community lacks of the tools for performing similar studies for quantifying various properties ofXSS attacks.','',3,0,'2021-06-21','2021-06-21','07:16:04','07:16:04'),(35,38,'Framework of Intrusion Detection System via Snort Application on Campus Network Environment','Virtual Private Network (VPN) technology has become a discussion issue for this time being. Today, the deployment of this IDS technology on an organization truly can give a great privacy and security benefit over campus environment. This study focuses on installation, configuring and implementation of snort in University of Kuala Lumpur network environment. In addition, we emphasis on access to a MySQL database, WINCAP and Perl scripts (PHP). Based on the finding result, the IDS over snort application is able to analyze and detect malware activity in client server environment over LAN.','',3,0,'2021-06-21','2021-06-21','09:03:48','09:03:48');
/*!40000 ALTER TABLE `rexpo_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_prodi`
--

DROP TABLE IF EXISTS `rexpo_prodi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_prodi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(256) NOT NULL,
  `id_fakultas` int(11) DEFAULT NULL,
  `jenjang` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nama` (`nama`),
  KEY `jenjang` (`jenjang`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_prodi`
--

LOCK TABLES `rexpo_prodi` WRITE;
/*!40000 ALTER TABLE `rexpo_prodi` DISABLE KEYS */;
INSERT INTO `rexpo_prodi` VALUES (1,'Manajemen',NULL,'s1'),(2,'Akuntansi',NULL,'s1'),(3,'Teknik Informatika',NULL,'s1'),(4,'Teknik Sipil',NULL,'s1'),(5,'Farmasi',NULL,'s1'),(6,'Agribisnis',NULL,'s1'),(7,'Agroteknologi',NULL,'s1'),(8,'Peternakan',NULL,'s1');
/*!40000 ALTER TABLE `rexpo_prodi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rexpo_vacancy`
--

DROP TABLE IF EXISTS `rexpo_vacancy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rexpo_vacancy` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id auto increment',
  `company_id` int(11) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `deskripsi` text NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 (closed)\r\n1 (open)',
  `date_created` date NOT NULL,
  `date_updated` date NOT NULL,
  `time_created` time NOT NULL,
  `time_updated` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_to_account` (`company_id`),
  KEY `status` (`status`),
  KEY `nama` (`nama`),
  CONSTRAINT `company_to_account` FOREIGN KEY (`company_id`) REFERENCES `rexpo_account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rexpo_vacancy`
--

LOCK TABLES `rexpo_vacancy` WRITE;
/*!40000 ALTER TABLE `rexpo_vacancy` DISABLE KEYS */;
/*!40000 ALTER TABLE `rexpo_vacancy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:22
