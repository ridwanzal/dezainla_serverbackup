-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: db_pdam
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_pdam`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_pdam` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_pdam`;

--
-- Table structure for table `t_admin`
--

DROP TABLE IF EXISTS `t_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) CHARACTER SET latin1 NOT NULL,
  `password` varchar(75) CHARACTER SET latin1 NOT NULL,
  `nama` varchar(15) CHARACTER SET latin1 NOT NULL,
  `level` enum('super admin','admin') CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_admin`
--

LOCK TABLES `t_admin` WRITE;
/*!40000 ALTER TABLE `t_admin` DISABLE KEYS */;
INSERT INTO `t_admin` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3','wahyu','super admin'),(3,'umum','adfab9c56b8b16d6c067f8d3cff8818e','wahyu','admin'),(4,'wahyu','32c9e71e866ecdbc93e497482aa6779f','wahyu','super admin');
/*!40000 ALTER TABLE `t_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_surat_masuk`
--

DROP TABLE IF EXISTS `t_surat_masuk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_surat_masuk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usulan_masuk` date NOT NULL,
  `surat_balasan` date NOT NULL,
  `unit_pelayanan` varchar(250) CHARACTER SET latin1 NOT NULL,
  `disposisi` enum('Dirut','Dirum','Dirops','Dirtek') CHARACTER SET latin1 NOT NULL,
  `uraian_usulan` varchar(500) CHARACTER SET latin1 NOT NULL,
  `kesimpulan_analisa` varchar(10000) CHARACTER SET latin1 NOT NULL,
  `tgl_diterima` date NOT NULL,
  `keterangan` varchar(250) CHARACTER SET latin1 NOT NULL,
  `file` varchar(200) CHARACTER SET latin1 NOT NULL,
  `pengolah` int(4) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_surat_masuk`
--

LOCK TABLES `t_surat_masuk` WRITE;
/*!40000 ALTER TABLE `t_surat_masuk` DISABLE KEYS */;
INSERT INTO `t_surat_masuk` VALUES (21,'2021-01-07','2021-01-13','rambutan','Dirum','','','2021-01-13','','',1,'Belum Lengkap'),(22,'2021-01-13','2021-01-13','Karang Anyar','Dirops','Analisa jaringan usulan pemasangan jaringan Perumahan Grand Nindya Residence JL. Tanjung Barangan Lr. Wallet\r\n(N0.690/1734/PDAM/2020)','Kondisi Eksisting lokasi analisa beranda pada wilayah Tanjung Barangan dan sekitarnya dengan jadwal panggilan 24 jam. Dari hasil analisa jaringan menggunakan software watercard, pipa sumber diameter 160 mm dengan tekanan pada puncak pemakalan pelanggan sebesar 0,5610 atm (turun 0,0330 atm) apabila dilakukan penambahan pelanggan sebesar 0,5610 atm menjadi 0,5280 atm (turun 0,0330 atm) apabila dilakukan penambahan jaringan perpipaan sebanyak +- 17 SL (Perumahan Grand Nindya Residence). Titik pantau.','2021-01-13','497/PKA/PDAM/X/2020','',1,'Sudah Lengkap'),(23,'2021-01-12','2021-01-13','rambutan','Dirops','Analisa jaringan usulan pemasangan jaringan Perumahan Barangan Indah Permai JL. Tanjung Bubuk Kel. Bukit Baru Kec. Ilir Barat 1\r\n(No.024/Opr-ZAA/VII/2020)','Kondisi Eksisting lokasi analisa beranda pada wilayah Tanjung Barangan dan sekitarnya dengan jadwal panggilan 24 jam. Dari hasil analisa jaringan menggunakan software watercard, pipa sumber diameter 160 mm dengan tekanan pada puncak pemakalan pelanggan sebesar 0,5610 atm (turun 0,0330 atm) apabila dilakukan penambahan pelanggan sebesar 0,5610 atm menjadi 0,5280 atm (turun 0,0330 atm) apabila dilakukan penambahan jaringan perpipaan sebanyak +- 17 SL (Perumahan Grand Nindya Residence). Titik panta','2021-01-13','498/PKA/PDAM/X/2020','Screenshot_20200528-093046_WhatsApp.jpg',1,'Sudah Lengkap'),(24,'2021-01-11','2021-01-13','Kertapati','Dirut','Analisa jaringan usulan pemasangan jaringan Perumahan Ogan Permain Indah JL. Gubernur Habstari, kel.Jakabaring Kec. Jakabaring\r\n(N0.130/1102/PDAM/2020)','','2021-01-13','489/PKA/PDAM/X/2020','pdam.jpg',1,'Belum Lengkap'),(25,'2021-01-12','2021-01-12','demang lebar daun','Dirtek','','','2021-01-13','','pdam1.jpg',1,'Belum Lengkap'),(26,'2021-01-13','2021-01-13','','Dirum','','','2021-01-13','590/PKA/PDAM/X/2020','',1,'Belum Lengkap'),(27,'2021-03-02','2021-03-03','alang alang lebar','Dirum','surat usulan pemindahan unit dan pembukaan cabang','telah disahkan oleh pemerintah mengenai penambahan cabang tirta musi di palembang','2021-03-03','wajib','',1,'Belum Lengkap');
/*!40000 ALTER TABLE `t_surat_masuk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr_instansi`
--

DROP TABLE IF EXISTS `tr_instansi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tr_instansi` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) CHARACTER SET latin1 NOT NULL,
  `alamat` varchar(100) CHARACTER SET latin1 NOT NULL,
  `pimpinan` varchar(100) CHARACTER SET latin1 NOT NULL,
  `nik` varchar(100) CHARACTER SET latin1 NOT NULL,
  `logo` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr_instansi`
--

LOCK TABLES `tr_instansi` WRITE;
/*!40000 ALTER TABLE `tr_instansi` DISABLE KEYS */;
INSERT INTO `tr_instansi` VALUES (1,'PDAM Tirta Musi Palembang','Jl. Rambutan Ujung No.1, 32 Ilir, Kec. Ilir Bar. II, Kota Palembang, Sumatera Selatan 30144','wahyu','09021381823116','Screenshot_20200528-093046_WhatsApp.jpg');
/*!40000 ALTER TABLE `tr_instansi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:19
