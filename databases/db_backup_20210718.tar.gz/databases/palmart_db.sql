-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: palmart_db
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `palmart_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `palmart_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `palmart_db`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `user_admin` varchar(255) NOT NULL,
  `password_admin` varchar(255) NOT NULL,
  `nama_admin` varchar(255) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','c5d5f5d424137bdfb448e16413b507b1','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner` (
  `id_banner` int(11) NOT NULL AUTO_INCREMENT,
  `nama_banner` varchar(255) NOT NULL,
  `deskripsi_banner` text NOT NULL,
  `gambar_banner` varchar(255) NOT NULL,
  `status_banner` int(11) NOT NULL,
  PRIMARY KEY (`id_banner`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
INSERT INTO `banner` VALUES (1,'Chemical','Chemical','259691191_Chemical.jpg',1),(2,'original sparepart','original sparepart','2048546546_original_sparepart.jpg',1),(3,'authorized dealer sumsel','authorized dealer sumsel','2133151791_authorized_dealer_sumsel.jpg',1),(4,'the rise of android laundry','the rise of android laundry','1830161352_the_rise_of_android_laundry.jpg',1),(5,'build better to last longer','kualitas terbaik untuk usaha anda','888152807_build_better_to_last_longer.jpg',1),(6,'speed queen','speed queen','1257867061_speed_queen.jpg',1);
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barang`
--

DROP TABLE IF EXISTS `barang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `deskripsi_barang` text NOT NULL,
  `gambar_barang` varchar(255) NOT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `id_kategori` (`id_kategori`),
  CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barang`
--

LOCK TABLES `barang` WRITE;
/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
INSERT INTO `barang` VALUES (7,'Boiler',9,'Alat yang digunakan untuk menyetrika pakaian lebih mudah dan rapi. ... Selain itu di mesin boiler ini juga dilengkapi dengan saluran parfum sehingga setelah selesai disetrika pakaian rapi dan juga harum.','1696513921_Boiler.jpg'),(8,'Carpet Polisher',9,'Carpet Polisher\r\n','876223683_Carpet_Polisher.jpg'),(9,'Meja Setrika Vacuum',9,'Meja Setrika Vacuum','607565253_Meja_Setrika_Vacuum.jpg'),(10,'Plastik Jinjing',9,'Plastik Jinjing','1887522139_Plastik_Jinjing.jpg'),(11,'Selang Setrika Uap',9,'Selang Setrika Uap','2024373692_Selang_Setrika_Uap.jpg'),(12,'Tagging Gun',9,'Tagging Gun','2057440513_Tagging_Gun.jpg'),(13,'Tagging Pin',9,'Tagging Pin','1852858245_Tagging_Pin.jpg'),(14,'Timbangan Digital',9,'Timbangan Digital','978734209_Timbangan_Digital.jpg'),(15,'As Shaft Dryer',10,'As Shaft Dryer','1706149178_As_Shaft_Dryer.jpg'),(16,'Belt Drum Dryer',10,'Belt Drum Dryer','1002050675_Belt_Drum_Dryer.jpg'),(17,'Coil Valve Set',10,'Coil Valve Set','1187735586_Coil_Valve_Set.jpg'),(18,'Idler Pulley Dryer',10,'Idler Pulley Dryer','1767724588_Idler_Pulley_Dryer.jpg'),(19,'Idler Pulley Washer',10,'Idler Pulley Washer','1602309352_Idler_Pulley_Washer.jpg'),(20,'Igniter',10,'Igniter','227329261_Igniter.jpg'),(21,'Knob Timer',10,'Knop Timer','1688250538_Knob_Timer.jpg'),(22,'Nepel Slang Konversi',10,'Nepel Slang Konversi','233838317_Nepel_Slang_Konversi.jpg'),(23,'Per Setrika Uap',10,'Per Setrika Uap','425696696_Per_Setrika_Uap.jpg'),(24,'Thermostat High Limit',10,'Thermostat High Limit','1385406572_Thermostat_High_Limit.jpg'),(25,'Machines Dryer Diamante Dryer 10,5 Kg',5,'Machines Dryer Diamante Dryer 10.5 Kg','65769200_Machines_Dryer_Diamante_Dryer_10,5_Kg.jpg'),(26,'Midea Washer 18 Kg',5,'Midea Washer 18 Kg','1438535723_Midea_Washer_18_Kg.jpg'),(27,'Speed Queen Tumble Dryer',5,'Speed Queen Tumble Dryer','1397895669_Speed_Queen_Tumble_Dryer.jpg'),(28,'Paket Laundry Android 2',4,'Laundry Equipment:\r\n\r\n1 Unit Washer Midea 18 Kg Garansi 1th (Laundry)\r\n1 Unit Dryer Speedqueen 15 Kg Garansi 3th (Laundry)\r\nFree Instalasi standar & Training\r\nFree Ongkir (Area Palembang)\r\n• Picklon (Sistem Pembayaran QR Code) + 3,7 Jt\r\n• Smartlink (Aplikasi Manajemen Laundry) + 1,5 Jt','1863242517_Paket_Laundry_Android_2.jpg'),(29,'Paket Bronze',4,'Paket Usaha Laundry Bronze','836695673_Paket_Bronze.jpg'),(30,'Paket Usaha Laundry Gold',4,'Paket Usaha Laundry Gold','1072266784_Paket_Usaha_Laundry_Gold.jpeg');
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id_blog` int(11) NOT NULL AUTO_INCREMENT,
  `judul_blog` varchar(255) NOT NULL,
  `isi_blog` text NOT NULL,
  `gambar_blog` varchar(255) NOT NULL,
  `tgl_blog` date NOT NULL,
  `waktu_blog` varchar(255) NOT NULL,
  PRIMARY KEY (`id_blog`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (7,'5 Cara untuk menjadi pebisnis laundry','Sebelum Anda mendalami lagi seluk-beluk bisnis laundry kiloan, ada baiknya Anda mengetahui mengapa Anda harus menggeluti bisnis ini. Bisnis laundry mungkin terkesan sepele. Anda hanya bertugas untuk mengurus pakaian-pakaian kotor dari orang yang bahkan tidak Anda kenal.\r\n\r\nPerlu diketahui, bisnis laundry kiloan merupakan peluang bisnis yang cukup besar. Bisnis ini memiliki target pasar yang cukup luas.\r\n\r\nBaca juga: 9 Peralatan Usaha Laundry Kiloan yang Wajib Disiapkan\r\n\r\nMeskipun Anda tidak bisa merangkul semuanya, tiap target merupakan pasar yang potensial untuk digali karena banyak yang membutuhkan laundry. Berikut beberapa target pasar yang bisa Anda tentukan.\r\n\r\n1. Mahasiswa\r\nTidak sedikit mahasiswa di kota-kota besar berasal dari luar daerah. Banyak pula dari mereka yang berasal dari kalangan menengah ke atas yang belum pernah mencuci sebelumnya. Selain itu, sebagian besar mahasiswa memilih untuk menyewa rumah kontrakan atau kosan selama mereka menempuh pendidikan.\r\n\r\nBaca Juga: Cara Membuka Usaha Cafe dengan Modal Minim\r\n\r\nKesibukan mereka sebagai mahasiswa membuat mereka tidak memiliki waktu untuk mencuci pakaiannya. Selain kesibukan, tentu saja keterbatasan peralatan cuci mencuci di kosannya masing-masing, atau bahkan rasa malas untuk mengurus tumpukan pakaian kotornya.\r\n\r\nOleh karena itu, banyak dari anak kos yang lebih memilih untuk memanfaatkan jasa laundry kiloan saja.\r\n\r\n2. Para pekerja kantoran\r\nSerupa tapi tak sama seperti mahasiswa, banyak juga para pekerja kantoran yang mencoba untuk hidup mandiri. Beberapa bahkan hidup mandiri karena tidak ada pilihan lain.\r\n\r\nMereka pun sadar bahwa waktu yang mereka miliki tidak seluwes saat zaman kuliah dulu. Harus berangkat pagi dan pulang malam hari pun membuat mereka tidak memiliki banyak waktu untuk mengurus pakaian kotor yang menumpuk.\r\n\r\nSelain itu, padatnya aktivitas harian para pekerja kantoran juga membuat mereka terlalu lelah untuk menyuci seluruh pakaian kotornya. Di sini lah para pekerja menggunakan jasa laundry untuk mengurus cucian mereka.\r\n\r\n3. Pasangan suami istri\r\nPasangan suami istri, baik tua maupun muda memiliki kesibukan dan tanggung jawab yang jauh berbeda dengan mahasiswa dan pekerja kantoran.\r\n\r\nTerutama bagi pasangan muda, suami istri biasanya memiliki jadwal yang sama sibuknya karena keduanya kerap sama-sama bekerja.\r\n\r\nMereka memiliki kesibukannya masing-masing dan itupun belum dihitung dengan masak, beberes rumah, hingga mengurus anak. Jika memiliki waktu libur saat akhir pekan pun, akan mereka pakai untuk bersantai bersama keluarga. Akhirnya, mereka lebih memilih untuk membawa cucian mereka ke laundry.\r\n\r\nDari ketiga poin di atas dapat dilihat bahwa bisnis laundry kiloan akan selalu memiliki tempat di pasar. Akan selalu ada mahasiswa, pekerja kantoran, dan pasangan suami istri baru setiap tahunnya. Hal ini yang membuat bisnis laundry dapat bertahan untuk waktu yang cukup lama.\r\n\r\nSelain itu, Anda pun tidak membutuhkan modal yang besar untuk merintis bisnis laundry dalam skala kecil. Sebagai permulaan untuk bisnis laundry kiloan, Anda harus menyiapkan beberapa peralatan seperti mesin cuci, setrika, serta timbangan.\r\n\r\nTidak lupa juga untuk menyiapkan peralatan pendukung seperti deterjen, pewangi, pelicin pakaian, ember, gantungan baju, dan lain sebagainya.\r\n\r\nKeuntungan yang didapatkan pun cukup menggiurkan. Sebagai contoh, diperkirakan Anda membutuhkan modal sekitar Rp10 juta untuk membeli peralatan serta biaya operasional.\r\n\r\nLalu Anda memasang tarif sebesar Rp6.000 per kilogram. Katakanlah bahwa Anda bisa mendapatkan hingga 50 kilogram pakaian per hari. Dalam sebulan Anda bisa mendapatkan omzet sekitar Rp6.620.000.','1381792867_5_Cara_untuk_menjadi_pebisnis_laundry.jpg','2020-02-29','05:53:40');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori`
--

LOCK TABLES `kategori` WRITE;
/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
INSERT INTO `kategori` VALUES (4,'Paket Usaha'),(5,'Mesin Laundry'),(9,'Perlengkapan'),(10,'Sparepart'),(11,'Laundry Furniture');
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `id_setting` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting` varchar(255) NOT NULL,
  `isi_setting` text NOT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'youtube','https://www.youtube.com/watch?v=wzfUjY3Zi8c');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ulasan`
--

DROP TABLE IF EXISTS `ulasan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ulasan` (
  `id_ulasan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_ulasan` varchar(255) NOT NULL,
  `deskripsi_ulasan` text NOT NULL,
  `gambar_ulasan` varchar(255) NOT NULL,
  `pekerjaan_ulasan` varchar(255) NOT NULL,
  `status_ulasan` int(11) NOT NULL,
  PRIMARY KEY (`id_ulasan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulasan`
--

LOCK TABLES `ulasan` WRITE;
/*!40000 ALTER TABLE `ulasan` DISABLE KEYS */;
INSERT INTO `ulasan` VALUES (5,'Chandra Ardian','Terimakasih banyak pak, Cepat selesai, bisa 4jam siap. 12ribu/kg minimum 3kg. Keren. Rapi wangi','377207193_Chandra_Ardian.png','Wong Laundry',0);
/*!40000 ALTER TABLE `ulasan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:22
