-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: maximus_hotel
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `maximus_hotel`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `maximus_hotel` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `maximus_hotel`;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('verifying','verified') NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `bukti` int(11) NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (16,'verifying',14,0,200000),(17,'verifying',14,0,375000),(18,'verifying',11,0,200000),(19,'verifying',14,0,350000),(20,'verifying',14,0,350000),(21,'verifying',15,0,350000),(22,'verifying',16,0,350000),(23,'verifying',17,0,200000),(24,'verifying',11,0,200000),(25,'verifying',14,0,0),(26,'verifying',14,0,375000);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_detail`
--

DROP TABLE IF EXISTS `booking_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_booking` int(11) NOT NULL,
  `id_room` int(11) NOT NULL,
  `lama_inap` int(11) NOT NULL,
  `jumlah_penginap` int(11) NOT NULL,
  `image_path` text NOT NULL,
  `tanggal_masuk` datetime NOT NULL,
  `tanggal_keluar` datetime NOT NULL,
  `status` enum('unpaid','progress','paidoff') NOT NULL DEFAULT 'unpaid',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_detail`
--

LOCK TABLES `booking_detail` WRITE;
/*!40000 ALTER TABLE `booking_detail` DISABLE KEYS */;
INSERT INTO `booking_detail` VALUES (27,14,16,17,1,1,'Capture1.PNG','2020-10-09 00:00:00','2020-10-10 00:00:00','paidoff'),(28,14,17,28,1,1,'Capture1.PNG','2020-10-16 00:00:00','2020-10-17 00:00:00','paidoff'),(29,11,18,18,1,1,'','2020-10-02 00:00:00','2020-10-03 00:00:00','paidoff'),(30,14,19,38,1,1,'Cth_Receipt2.jpg','2020-10-15 00:00:00','2020-10-16 00:00:00','paidoff'),(31,14,20,39,1,1,'Capture11.PNG','2020-10-15 00:00:00','2020-10-16 00:00:00','paidoff'),(32,15,21,40,1,1,'Capture22.PNG','2020-11-28 00:00:00','2020-11-29 00:00:00','paidoff'),(33,16,22,41,1,1,'Capture23.PNG','2020-10-17 00:00:00','2020-10-18 00:00:00','paidoff'),(34,17,23,19,1,1,'Capture61.PNG','2020-10-23 00:00:00','2020-10-24 00:00:00','paidoff'),(35,11,24,20,1,1,'','2020-10-12 00:00:00','2020-10-13 00:00:00','paidoff'),(36,14,25,42,0,1,'Cth_Receipt3.jpg','2020-10-31 00:00:00','2020-10-31 00:00:00','paidoff'),(37,14,26,30,1,1,'','2020-11-05 00:00:00','2020-11-06 00:00:00','paidoff');
/*!40000 ALTER TABLE `booking_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` text NOT NULL,
  `content` text NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES (7,'Ayo buruan ada diskon 25% pesan sekarang juga','Ayo pesan sekarang juga','2020-05-15 20:12:11'),(8,'weekend promo','Ayo buruan reservasi kamar yang kamu inginkan di weekend kali ini, nikmati moment weekend kamu bersama keluarga.','2020-11-04 22:56:16');
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hubungi`
--

DROP TABLE IF EXISTS `hubungi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hubungi` (
  `id_hubungi` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `telepon` text NOT NULL,
  `subjek` text NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` datetime NOT NULL,
  PRIMARY KEY (`id_hubungi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hubungi`
--

LOCK TABLES `hubungi` WRITE;
/*!40000 ALTER TABLE `hubungi` DISABLE KEYS */;
/*!40000 ALTER TABLE `hubungi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komentar`
--

DROP TABLE IF EXISTS `komentar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komentar` (
  `id_komentar` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` int(11) NOT NULL,
  `isi_komentar` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  PRIMARY KEY (`id_komentar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komentar`
--

LOCK TABLES `komentar` WRITE;
/*!40000 ALTER TABLE `komentar` DISABLE KEYS */;
/*!40000 ALTER TABLE `komentar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komentar_child`
--

DROP TABLE IF EXISTS `komentar_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komentar_child` (
  `id_komentar_child` int(11) NOT NULL AUTO_INCREMENT,
  `id_komentar` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `pesan` text NOT NULL,
  PRIMARY KEY (`id_komentar_child`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komentar_child`
--

LOCK TABLES `komentar_child` WRITE;
/*!40000 ALTER TABLE `komentar_child` DISABLE KEYS */;
/*!40000 ALTER TABLE `komentar_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `id_room` int(11) NOT NULL AUTO_INCREMENT,
  `room_number` int(11) NOT NULL,
  `deskripsi` text NOT NULL,
  `status` enum('available','reserved') NOT NULL,
  `diskon` int(11) NOT NULL,
  `thumbnail` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  PRIMARY KEY (`id_room`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (17,1,'','reserved',0,0,200000,1),(18,1,'','reserved',0,0,200000,1),(19,2,'','reserved',0,0,200000,1),(20,3,'','reserved',0,0,200000,1),(21,4,'','available',0,0,200000,1),(22,5,'','available',0,0,200000,1),(23,6,'','available',0,0,200000,1),(24,7,'','available',0,0,200000,1),(25,8,'','available',0,0,200000,1),(26,9,'','available',0,0,200000,1),(27,10,'','available',0,0,200000,1),(28,1,'','reserved',25,0,500000,4),(29,2,'','available',25,0,500000,4),(30,3,'','reserved',25,0,500000,4),(31,4,'','available',25,0,500000,4),(32,5,'','available',25,0,500000,4),(33,6,'','available',25,0,500000,4),(34,7,'','available',25,0,500000,4),(35,8,'','available',25,0,500000,4),(36,9,'','available',25,0,500000,4),(37,10,'','available',25,0,500000,4),(38,1,'','reserved',0,0,350000,3),(39,2,'','reserved',0,0,350000,3),(40,3,'','reserved',0,0,350000,3),(41,4,'','reserved',0,0,350000,3),(42,5,'','reserved',0,0,350000,3),(43,6,'','available',0,0,350000,3),(44,7,'','available',0,0,350000,3),(45,8,'','available',0,0,350000,3),(46,9,'','available',0,0,350000,3),(47,10,'','available',0,0,350000,3);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_category`
--

DROP TABLE IF EXISTS `room_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_category`
--

LOCK TABLES `room_category` WRITE;
/*!40000 ALTER TABLE `room_category` DISABLE KEYS */;
INSERT INTO `room_category` VALUES (1,'Standard Room'),(3,'Double Room'),(4,'Junior Room'),(5,'Deluxe Room');
/*!40000 ALTER TABLE `room_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimoni`
--

DROP TABLE IF EXISTS `testimoni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimoni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `pesan` text NOT NULL,
  `rate_kamar` int(11) NOT NULL,
  `rate_kebersihan` int(11) NOT NULL,
  `rate_layanan` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimoni`
--

LOCK TABLES `testimoni` WRITE;
/*!40000 ALTER TABLE `testimoni` DISABLE KEYS */;
INSERT INTO `testimoni` VALUES (1,1,'2020-05-06 08:31:54','Terbaik, pengalaman menginap disini sangat memuaskan, kamar bersih, nyaman, tidak berisik dan yang pasti banyak nilai tambah, breakfast disedikan dengan kategori / tipe room manapun. Pokoknya worth it buat nginep di Maximus. Kalo ada waktu buat berkunjung ke palembang, bakal pilih hotel ini.',5,5,5),(2,9,'2020-05-06 08:34:29','Awalnya sempat underestimated dengan hotel ini, tapi ternyata hotel ini oke punya terutama mengenai masalah pelayanan staff hotel.. Helpfull pokoknya. Kalau dari segi kamar dan yg lainnya sih so so lah toh kalau di yogya juga cm numpang mandi tidur sm simpan barang kok. Begitu masuk ke hotel kita akan langsung disambut dengan musik gamelan khas jawa. Belum lagi lokasinya yg berdekatan debgan daerah prawirotaman. Pokoknya kalau yg mau tinggal di daerah yg tenang ya nginap di hotel ini',4,5,5),(3,11,'2020-05-06 09:38:02','Lokasi yang strategis karena dekat dengan pusat kuliner dan juga tidak jauh dengan pusat pusat perbelanjaan. Kamar sangat bersih dan makanan nya enak seseuai lidah indonesia. Staff yang service nya outstanding adalah mba diah. Thank you cemara hotel sangat memuaskan pelayanan nya',4,5,5),(4,14,'2020-10-31 12:08:27','Kamar bersih dan wangi serta pelayanan memuaskan',4,4,5);
/*!40000 ALTER TABLE `testimoni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimoni_reply`
--

DROP TABLE IF EXISTS `testimoni_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimoni_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_testimoni` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `pesan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimoni_reply`
--

LOCK TABLES `testimoni_reply` WRITE;
/*!40000 ALTER TABLE `testimoni_reply` DISABLE KEYS */;
INSERT INTO `testimoni_reply` VALUES (34,3,10,'2020-05-13 17:38:25','terima kasih atas review ny'),(35,2,10,'2020-11-04 22:49:36','terimakasih\n'),(36,4,10,'2020-11-04 22:49:58','Terimakasih ');
/*!40000 ALTER TABLE `testimoni_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `role` enum('pelanggan','admin') NOT NULL,
  `email` varchar(128) NOT NULL,
  `telepon` bigint(20) NOT NULL,
  `alamat` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (9,'alif','Alif Ginanjar','pelanggan','alifginanjar@gmail.com',811100100200,'Palembang, Seberang Ulu, Jakabring','202cb962ac59075b964b07152d234b70'),(10,'admin','Administrator','admin','maximus@gmail.com',711890901,'Hotel Maximus Palembang - Jalan Angan Angan 2','202cb962ac59075b964b07152d234b70'),(11,'rendi','Rendiansyah','pelanggan','zalbinaridwan@gmail.com',81213132121,'Perumahan Green Garden, Prabumulih','202cb962ac59075b964b07152d234b70'),(12,'bariahmad','Bari Ahmad','pelanggan','bariahmad@gmail.com',812112123412,'Jl. Mahoni Raya Palembang','e10adc3949ba59abbe56e057f20f883e'),(13,'ginan','ginanjar','pelanggan','ginan@gmail.com',85309098007,'palembang','827ccb0eea8a706c4c34a16891f84e7b'),(14,'alifgp','Alif Ginanjar Putranda','pelanggan','alifgp20@gmail.com',92381827576,'Palembang','202cb962ac59075b964b07152d234b70'),(15,'putra1','putra sanjaya','pelanggan','putra1@gmail.com',87899007654,'bekasi','202cb962ac59075b964b07152d234b70'),(16,'citra','citra kirana','pelanggan','citrakir@gmail.com',85678900087,'jakarta','202cb962ac59075b964b07152d234b70'),(17,'dita','dita laura','pelanggan','dita111@gmail.com',87788976556,'depok','202cb962ac59075b964b07152d234b70'),(18,'jaya','jaya','pelanggan','BakuHantamCrew@gmail.com',83833571194,'Aceh','c892c5f62f743053a52f8336b697eee5');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-18 12:32:22
